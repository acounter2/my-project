<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_verify = "127.0.0.1";
$database_verify = "verification_system";
$username_verify = "root";
$password_verify = "";
$verify = mysql_pconnect($hostname_verify, $username_verify, $password_verify) or trigger_error(mysql_error(),E_USER_ERROR); 
?>