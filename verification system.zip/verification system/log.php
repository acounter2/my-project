<?php require_once('Connections/verify.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_verify, $verify);
$query_Recordset1 = "SELECT admin_name, admin_pass FROM `admin`";
$Recordset1 = mysql_query($query_Recordset1, $verify) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
?>
<?php
// *** Validate request to login to this site.
if (!isset($_SESSION)) {
  session_start();
}

$loginFormAction = $_SERVER['PHP_SELF'];
if (isset($_GET['accesscheck'])) {
  $_SESSION['PrevUrl'] = $_GET['accesscheck'];
}

if (isset($_POST['username'])) {
  $loginUsername=$_POST['username'];
  $password=$_POST['password'];
  $MM_fldUserAuthorization = "";
  $MM_redirectLoginSuccess = "home.php";
  $MM_redirectLoginFailed = "log.php";
  $MM_redirecttoReferrer = false;
  mysql_select_db($database_verify, $verify);
  
  $LoginRS__query=sprintf("SELECT admin_name, admin_pass FROM `admin` WHERE admin_name=%s AND admin_pass=%s",
    GetSQLValueString($loginUsername, "text"), GetSQLValueString($password, "int")); 
   
  $LoginRS = mysql_query($LoginRS__query, $verify) or die(mysql_error());
  $loginFoundUser = mysql_num_rows($LoginRS);
  if ($loginFoundUser) {
     $loginStrGroup = "";
    
	if (PHP_VERSION >= 5.1) {session_regenerate_id(true);} else {session_regenerate_id();}
    //declare two session variables and assign them
    $_SESSION['MM_Username'] = $loginUsername;
    $_SESSION['MM_UserGroup'] = $loginStrGroup;	      

    if (isset($_SESSION['PrevUrl']) && false) {
      $MM_redirectLoginSuccess = $_SESSION['PrevUrl'];	
    }
    header("Location: " . $MM_redirectLoginSuccess );
  }
  else {
    header("Location: ". $MM_redirectLoginFailed );
  }
}
?>
<!DOCTYPE html> 
<html>

<head>
  <title>PIS E-Verify System</title>
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=windows-1252" />
  <link rel="stylesheet" type="text/css" href="css/style.css" />
  <!-- modernizr enables HTML5 elements and feature detects -->
  <script type="text/javascript" src="js/modernizr-1.5.min.js"></script>
</head>

<body>
  <div id="main">		

    <header>
	  <div id="strapline">
	    <div id="welcome_slogan">
	      <h3><font color="#FFFFFF">PRINCE INTERNATIONAL SCHOOL</font>  <font color="#FF0000"><strong>(E-Verify)</strong> <span> <em>SYSTEM</em></span></font></h3>
	    </div><!--close welcome_slogan-->
      </div><!--close strapline-->	  
	  <nav>
	    <div id="menubar">
          <ul id="nav">
           <li><a href="index.php">Home</a></li>
            <li><a href="about.php">About PIS</a></li>
             <li><a href="award.php">Awards</a></li>
          
         
          </ul>
        </div><!--close menubar-->	
      </nav>
    </header>
    
    <div id="slideshow_container">  
	  <div class="slideshow">
	    <ul class="slideshow">
          <li class="show"><img width="940" height="400" src="image/v2.jpg" alt="E-Verification is the way" /></li>
          <li><img width="940" height="500" src="images/home_2.jpg" alt="Prince International School Talata Mafara" /></li>
          <li><img width="940" height="500" src="images/images (8).jpg" alt="Education is the key to success" /></li>
          <li><img width="940" height="187" src="images/images (6).jpg" alt="Visit Our School Today" /></li>
        </ul> 
	  </div><!--close slideshow-->  	
	</div>   
	

    <table width="100%" border="0">
  <tr>
    <td height="269" align="center" valign="top"><p>&nbsp;</p>
      <form name="form1" method="POST" action="<?php echo $loginFormAction; ?>">
        <table width="24%" border="0">
          <tr>
            <td height="24" bgcolor="#0043A8">&nbsp;</td>
          </tr>
          <tr>
            <td height="23" bgcolor="#0043A8"><h3><font color="#FFFFFF">Username</font></h3></td>
          </tr>
          <tr>
            <td bgcolor="#0043A8"><label for="username"></label>
              <input name="username" type="text" id="username" size="40" placeholder="username"></td>
          </tr>
          <tr>
            <td height="25" bgcolor="#0043A8"><h3><font color="#FFFFFF">Password</font></h3></td>
          </tr>
          <tr>
            <td bgcolor="#0043A8"><label for="password"></label>
              <input name="password" type="password" id="password" size="40" placeholder="password"></td>
          </tr>
          <tr>
            <td bgcolor="#0043A8"><input type="submit" name="ok" id="ok" value="    Ok    "></td>
          </tr>
        </table>
      </form>
      <p>&nbsp;</p></td>
  </tr>
</table>

    
    
    
    
    
    
      
	
    <footer>
	  Developed By:SOMOSCO
    </footer>
	
  </div><!--close main-->
  
  <!-- javascript at the bottom for fast page loading -->
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/image_slide.js"></script>
  
</body>
</html>
<?php
mysql_free_result($Recordset1);
?>
