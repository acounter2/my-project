<!DOCTYPE html> 
<html>

<head>
  <title>PIS E-Verify System</title>
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=windows-1252" />
  <link rel="stylesheet" type="text/css" href="css/style.css" />
  <style type="text/css">
  #main p {
	color: #F00;
}
  .JH {
	text-align: center;
	font-weight: bold;
}
  #main p {
	font-size: x-large;
}
  #main header #strapline #welcome_slogan h3 font span em {
}
  #main header #strapline #welcome_slogan h3 font strong {
	font-style: italic;
}
  </style>
  <!-- modernizr enables HTML5 elements and feature detects -->
  <script type="text/javascript" src="js/modernizr-1.5.min.js"></script>
</head>

<body>
<div id="main">		

    <header>
	  <div id="strapline">
	    <div id="welcome_slogan">
	      <h3><font color="#FFFFFF">PRINCE INTERNATIONAL SCHOOL</font>  <font color="#FF0000"><strong>(E-Verify)</strong> <span> <em>SYSTEM</em></span></font></h3>
	    </div><!--close welcome_slogan-->
      </div><!--close strapline-->	  
	  <nav>
	    <div id="menubar">
          <ul id="nav">
           <li><a href="log.php">Admin</a></li>
            <li><a href="">About PIS</a></li>
          
         
          </ul>
        </div><!--close menubar-->	
      </nav>
    </header>
    
    <div id="slideshow_container">  
	  <div class="slideshow">
	    <ul class="slideshow">
          <li class="show"><img width="940" height="400" src="image/v2.jpg" alt="E-Verification is the way" /></li>
          <li><img width="940" height="500" src="images/home_2.jpg" alt="Prince International School Talata Mafara" /></li>
          <li><img width="940" height="500" src="images/images (8).jpg" alt="Education is the key to success" /></li>
          <li><img width="940" height="187" src="images/images (6).jpg" alt="Visit Our School Today" /></li>
        </ul> 
	  </div><!--close slideshow-->  	
	</div>
    <p>
      <!--close slideshow_container--></p>
      <style>
	  @media print{
		  /* Hide every other element */
		  body * {
			  visibility:hidden;
		  }
		  /* then displaying print container element */
		  .print-container, .print-container *{
			  visibility:visible;
		  }
		  }
		  
	  
	  </style>
      <button onClick="window.print() ">print</button>
      
    <div class="row print-container">
    <p>&nbsp;</p>
    <p><span class="JH">WE ARE SO SORRY!! THE SITE IS STILL UNDER CONSTRUCTION</span></p>
  <p><strong>KINDLY CHECK BACK LATER AFTER MAINTAINANCE!</strong></p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
       
  <footer>
	  COPYRIGHT YUSIEFSON 2020
all right reserved.
    </footer>
	
  </div><!--close main-->
  
  <!-- javascript at the bottom for fast page loading -->
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/image_slide.js"></script>
  
</body>
</html>