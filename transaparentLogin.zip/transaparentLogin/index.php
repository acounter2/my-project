<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>login</title>
<link rel="stylesheet" type="text/css" href="style.css" />
<style type="text/css">
body {
	background-repeat: no-repeat;
	margin-left: 50px;
	margin-right: 50px;
}
</style>
</head>


<body background="image/B.jpg" text="#00FF00">
	
    <div class="login-box">
<h1>Login</h1>
	<form action="customerpage.php" method="get">
    <div class="textbox">
	<input type="text" placeholder="username" name="" value="" />
</div>
	<div class="textbox">
	<input type="password" placeholder="password" name="" value="" />
</div>
<input class="btn" type="button" name="" value="Sign in" /> 
<font color="#00CC00">Register</font>
	</form>
</div>

</body>
</html>