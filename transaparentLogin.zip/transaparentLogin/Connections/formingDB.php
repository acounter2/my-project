<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_formingDB = "127.0.0.1";
$database_formingDB = "forming";
$username_formingDB = "root";
$password_formingDB = "";
$formingDB = mysql_pconnect($hostname_formingDB, $username_formingDB, $password_formingDB) or trigger_error(mysql_error(),E_USER_ERROR); 
?>