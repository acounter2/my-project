<?php require_once('Connections/MUSEUM.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}
?>
<?php
// *** Validate request to login to this site.
if (!isset($_SESSION)) {
  session_start();
}

$loginFormAction = $_SERVER['PHP_SELF'];
if (isset($_GET['accesscheck'])) {
  $_SESSION['PrevUrl'] = $_GET['accesscheck'];
}

if (isset($_POST['login'])) {
  $loginUsername=$_POST['login'];
  $password=$_POST['pass'];
  $MM_fldUserAuthorization = "";
  $MM_redirectLoginSuccess = "museum.php";
  $MM_redirectLoginFailed = "login.php";
  $MM_redirecttoReferrer = false;
  mysql_select_db($database_MUSEUM, $MUSEUM);
  
  $LoginRS__query=sprintf("SELECT username, password FROM register WHERE username=%s AND password=%s",
    GetSQLValueString($loginUsername, "text"), GetSQLValueString($password, "text")); 
   
  $LoginRS = mysql_query($LoginRS__query, $MUSEUM) or die(mysql_error());
  $loginFoundUser = mysql_num_rows($LoginRS);
  if ($loginFoundUser) {
     $loginStrGroup = "";
    
	if (PHP_VERSION >= 5.1) {session_regenerate_id(true);} else {session_regenerate_id();}
    //declare two session variables and assign them
    $_SESSION['MM_Username'] = $loginUsername;
    $_SESSION['MM_UserGroup'] = $loginStrGroup;	      

    if (isset($_SESSION['PrevUrl']) && false) {
      $MM_redirectLoginSuccess = $_SESSION['PrevUrl'];	
    }
    header("Location: " . $MM_redirectLoginSuccess );
  }
  else {
    header("Location: ". $MM_redirectLoginFailed );
  }
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>wellcome to our museum | kindly feel free and lookaround</title>
<style type="text/css">
body,td,th {
	font-family: "Lucida Console", Monaco, monospace;
	color: #000000;
	text-align: center;
}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
}
a:active {
	text-decoration: none;
}
h1,h2,h3,h4,h5,h6 {
	font-family: Arial, Helvetica, sans-serif;
}
a {
	font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
	color: #CCC;
}
.hj {
	color: #660000;
}
.ff {
	color: #930;
}
</style>
</head>

<body background="images/body-bg.gif">
<p>&nbsp;</p>
<p>&nbsp;</p>
<p><img src="images/new.jpg" width="1327" height="200" alt="m" /></p>
<p><a href="index.php">HOMEPAGE</a> <a href="history.php">HISTORY OF KANO</a> <a href="collection.php">VIEW COLLECTION</a> <a href="gallery.php">CHECK GALLERY</a> <a href="about.php">ABOUT US</a></p>
<table width="672" height="260" border="0" align="center" cellpadding="0" cellspacing="0" dir="ltr">
  <tr>
    <th height="154" bgcolor="#FFFFFF" scope="col"><strong><img src="images/users.png" width="130" height="134" alt="adm2" /><img src="images/adminuser.png" width="128" height="128" alt="u" /><span class="hj">|</span><img src="images/kuj.png" width="99" height="117" alt="bg" /></strong><img src="images/services_but.png" width="125" height="134" alt="adm" /></th>
  </tr>
  <tr>
    <th width="800" height="106" bgcolor="#CCCCCC" scope="col"><form id="form1" name="form1" method="POST" action="<?php echo $loginFormAction; ?>">
      <p>Visitor I_D
        <label for="login"></label>
        <input type="text" name="login" placeholder="visitor name" id="login" />
      </p>
      <p>Pasword    Key
        <label for="pass"></label>
        <input type="password" name="pass" placeholder="security pass"id="pass" />
      </p>
      <p>
        <input type="submit" name="log" id="log" value="Login" />
        |new visitor?<a href="reg.php" class="ff"> click here| </a></p>
    </form></th>
  </tr>
</table>
</body>
</html>