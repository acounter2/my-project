<?php require_once('Connections/MUSEUM.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_MUSEUM, $MUSEUM);
$query_Recordset1 = "SELECT * FROM art";
$Recordset1 = mysql_query($query_Recordset1, $MUSEUM) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>wellcome to our museum | kindly feel free and lookaround</title>
<style type="text/css">
body,td,th {
	font-family: "Lucida Console", Monaco, monospace;
	color: #663300;
	text-align: center;
}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
}
a:active {
	text-decoration: none;
}
h1,h2,h3,h4,h5,h6 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
}
a {
	font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
	color: #CCC;
}
.I {
	font-style: italic;
}
vf {
	font-weight: bold;
}
#page p {
	font-size: large;
	font-weight: bold;
}
#page .ui-br div table {
	color: #66FFFF;
}
</style>
<link href="jquery-mobile/jquery.mobile.theme-1.0.min.css" rel="stylesheet" type="text/css" />
<link href="jquery-mobile/jquery.mobile.structure-1.0.min.css" rel="stylesheet" type="text/css" />
<script src="jquery-mobile/jquery-1.6.4.min.js" type="text/javascript"></script>
<script src="jquery-mobile/jquery.mobile-1.0.min.js" type="text/javascript"></script>
</head>

<body background="images/body-bg.gif">
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;

<div data-role="page" id="page">
  <div data-role="header">
    <h1>&nbsp;</h1>
    <h1><img src="images/new.jpg" width="1096" height="143" alt="m" /></h1>
    <h1><a href="index.php">HOMEPAGE</a> <a href="history.php">HISTORY OF KANO</a> <a href="collection.php">VIEW COLLECTION</a> <a href="gallery.php">CHECK GALLERY</a> <a href="about.php">ABOUT US</a></h1>
  </div>
  <p>Wellcome to our Art Section  
  
  <p>
  <div class="ui-br" data-role="content">
    <div data-inline="true"></div>
    <div data-role="fieldcontain">
      <p>&nbsp;</p>
      <table width="1398" border="1" cellpadding="4" cellspacing="4">
        <tr>
          <th align="center" bgcolor="#CCCCCC">Image</th>
          <th align="center" bgcolor="#CCCCCC">art_title</th>
          <th align="center" bgcolor="#CCCCCC">art_name</th>
          <th align="center" bgcolor="#CCCCCC">art_origin</th>
          <th align="center" bgcolor="#CCCCCC">art_discover</th>
          <th align="center" bgcolor="#CCCCCC">art_uses</th>
          <th align="center" bgcolor="#CCCCCC">edit</th>
          <th align="center" bgcolor="#CCCCCC">delete</th>
          <th align="center" bgcolor="#CCCCCC">uploader</th>
        </tr>
        <?php do { ?>
          <tr>
            <td align="center"><img src="imageArt/<?php echo $row_Recordset1['art_name']; ?>.png" width="48" height="48" alt="ki" /></td>
            <td><?php echo $row_Recordset1['art_title']; ?></td>
            <td><?php echo $row_Recordset1['art_name']; ?></td>
            <td><?php echo $row_Recordset1['art_origin']; ?></td>
            <td><?php echo $row_Recordset1['art_discover']; ?></td>
            <td><?php echo $row_Recordset1['art_uses']; ?></td>
            <td><a href="updateart.php?art_id=<?php echo $row_Recordset1['art_id']; ?>"><img src="images/products_but.png" width="65" height="43" alt="tre" /></a></td>
            <td><a href="deleteart.php?art_id=<?php echo $row_Recordset1['art_id']; ?>"><img src="images/close.png" width="65" height="43" alt="iu" /></a></td>
            <td><form id="form1" name="form1" method="post" action="">
              <input type="submit" name="btn_load" id="btn_load" value="Submit" />
              <input name="hf_uname" type="hidden" id="hf_uname" value="<?php echo $row_Recordset1['art_name']; ?>" />
            </form></td>
          </tr>
          <?php } while ($row_Recordset1 = mysql_fetch_assoc($Recordset1)); ?>
      </table>
<p>&nbsp;<a href="addart.php">add new</a>
  <a href="searchart.php">search art</a>
<div class="ui-grid-a">
        <div class="ui-block-a">&lt;PREVIOUS        </div>
        <div class="ui-block-b">NEXT&gt;</div>
      </div>
      </p>
    </div>
  </div>
  <div data-role="footer">&copy; YUSIEFON 2020</div>
</div>
</p>
</body>
</html>
<?php
mysql_free_result($Recordset1);
?>
