<?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "index.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "login.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($_SERVER['QUERY_STRING']) && strlen($_SERVER['QUERY_STRING']) > 0) 
  $MM_referrer .= "?" . $_SERVER['QUERY_STRING'];
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>wellcome to our museum | kindly feel free and lookaround</title>
<style type="text/css">
body,td,th {
	font-family: "Lucida Console", Monaco, monospace;
	color: #FFFFFF;
	text-align: center;
}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
}
a:active {
	text-decoration: none;
}
h1,h2,h3,h4,h5,h6 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
}
a {
	font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
	color: #CCC;
}
.I {
	font-style: italic;
}
K {
	text-align: left;
}
K {
	text-align: left;
}
</style>
<link href="jquery-mobile/jquery.mobile.theme-1.0.min.css" rel="stylesheet" type="text/css" />
<link href="jquery-mobile/jquery.mobile.structure-1.0.min.css" rel="stylesheet" type="text/css" />
<script src="jquery-mobile/jquery-1.6.4.min.js" type="text/javascript"></script>
<script src="jquery-mobile/jquery.mobile-1.0.min.js" type="text/javascript"></script>
</head>

<body background="images/body-bg.gif">
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;

<div data-role="page" id="page">
  <div data-role="header">
    <h1>&nbsp;</h1>
    <h1><img src="images/new.jpg" width="1096" height="143" alt="m" /></h1>
    <table width="200" border="1" cellspacing="0" cellpadding="0">
      <tr>
        <th scope="col"><a href="<?php echo $logoutAction ?>">LOGOUT USER</a></th>
      </tr>
    </table>
    <h1><a href="index.php">HOMEPAGE</a> <a href="history.php">HISTORY OF KANO</a> <a href="collection.php">VIEW COLLECTION</a> <a href="gallery.php">CHECK GALLERY</a> <a href="about.php">ABOUT US	</a></h1>
  </div>
  <p>Our museum contain of 11 Galleries, feel free to navigate to each gallery.......    		
  <div class="ui-br" data-role="content">
    <div data-inline="true">
      <button data-inline="true" data-icon="forward" data-iconpos="right">Welcome</button>
      <button data-inline="true" data-icon="forward" data-iconpos="right">to Gallery</button>
    </div>
    <img src="images/2015_11largeimg121_Nov_2015_234218113-580x387.jpg" width="794" height="387" alt="G" />
    <div data-role="fieldcontain">
      <p>
        <label for="slider">Value:</label>
        <input type="search" name="slider" id="slider" value="What do you want to search?" min="0" max="100" />
      </p>
      <table width="200" border="0" align="center" cellpadding="2" cellspacing="5">
        <tr>
          <th scope="col"><img src="images/Picture1.png" width="145" height="149" alt="WE" /></th>
          <th scope="col"><img src="images/Kano-Museum1.jpg" width="135" height="149" alt="WR" /></th>
          <th scope="col"><img src="images/about01.jpg" width="135" height="149" /></th>
          <th scope="col"><img src="images/caption.jpg" width="135" height="149" alt="WY" /></th>
          <th scope="col"><img src="images/images (2).jpg" width="135" height="149" alt="WU" /></th>
          <th scope="col"><img src="images/images (4).jpg" width="135" height="149" alt="WI" /></th>
        </tr>
        <tr>
          <th scope="row">traditional</th>
          <td>zaure</td>
          <td>land</td>
          <td>map of kano</td>
          <td>history of statehold</td>
          <td>industry</td>
        </tr>
        <tr>
          <th scope="row"><img src="images/images (5).jpg" width="135" height="149" alt="wa" /></th>
          <td><img src="images/images (7).jpg" width="135" height="149" alt="wd" /></td>
          <td><img src="images/images (6).jpg" width="135" height="149" alt="wg" /></td>
          <td><img src="images/download (7).jpg" width="135" height="149" alt="c" /></td>
          <td><img src="images/download (6).jpg" width="135" height="149" alt="n" /></td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <th scope="row">economy</th>
          <td>kano city walls</td>
          <td>kano century</td>
          <td>music and dance</td>
          <td>the civil war</td>
          <td>&nbsp;</td>
        </tr>
      </table>
      <p>&nbsp;</p>
    </div>
  </div>
  <div data-role="footer">&copy; YUSIEFON 2020</div>
</div>
</p>
</body>
</html>