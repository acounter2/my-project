<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "false";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && false) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "admin.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($_SERVER['QUERY_STRING']) && strlen($_SERVER['QUERY_STRING']) > 0) 
  $MM_referrer .= "?" . $_SERVER['QUERY_STRING'];
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>wellcome to our museum | kindly feel free and lookaround</title>
<style type="text/css">
body,td,th {
	font-family: "Lucida Console", Monaco, monospace;
	color: #663300;
	text-align: center;
}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
}
a:active {
	text-decoration: none;
}
h1,h2,h3,h4,h5,h6 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
}
a {
	font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
	color: #CCC;
}
.I {
	font-style: italic;
}
vf {
	font-weight: bold;
}
#page p {
	font-size: large;
	font-weight: bold;
}
</style>
<link href="jquery-mobile/jquery.mobile.theme-1.0.min.css" rel="stylesheet" type="text/css" />
<link href="jquery-mobile/jquery.mobile.structure-1.0.min.css" rel="stylesheet" type="text/css" />
<script src="jquery-mobile/jquery-1.6.4.min.js" type="text/javascript"></script>
<script src="jquery-mobile/jquery.mobile-1.0.min.js" type="text/javascript"></script>
</head>

<body background="images/body-bg.gif">
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;

<div data-role="page" id="page">
  <div data-role="header">
    <h1>&nbsp;</h1>
    <h1><img src="images/new.jpg" width="1096" height="143" alt="m" /></h1>
    <h1><a href="index.php">HOMEPAGE</a> <a href="history.php">HISTORY OF KANO</a> <a href="collection.php">VIEW COLLECTION</a> <a href="gallery.php">CHECK GALLERY</a> <a href="about.php">ABOUT US</a></h1>
  </div>
  <p>You are viewing this page because you are an admin!
  <p>
  <div data-role="fieldcontain">
    <label for="selectmenu" class="select">Select what you want tO EDIT,INSERT,DELETE:</label>
    <select name="selectmenu" id="selectmenu">
      <option value="ART.PHP"><a href="art.php">ARTS</a></option>
      <option value="RECORDS">RECORDS</option>
      <option value="CRAFTS">CRAFTS</option>
      <option value="VISITORS">VISITORS</option>
      <option value="STAFFS">STAFFS</option>
      <option value="ITEMS">OTHER ITEMS</option>
    </select>
  </div>
  <p>
  <table width="200" border="1" align="center" cellpadding="0" cellspacing="0">
    <tr>
      <th scope="col"><img src="images/about03.jpg" width="128" height="120" alt="ft" /></th>
      <th scope="col"><img src="images/gallery/06.jpg" width="128" height="120" alt="ghy" /></th>
      <th scope="col"><img src="images/gallery/12.jpg" width="128" height="120" alt="ver" /></th>
    </tr>
    <tr>
      <th scope="row"><a href="visitor2.php">visitors</a></th>
      <td><a href="art2.php">Art</a></td>
      <td><a href="craft2.php">Craft</a></td>
    </tr>
    <tr>
      <th scope="row"><img src="images/gallery/04.jpg" width="128" height="120" alt="ytr" /></th>
      <td><img src="images/post_image/Admin Block Cabs-tn.JPG" width="128" height="120" alt="awe" /></td>
      <td><img src="images/50_64x64.png" width="128" height="120" alt="dsa" /></td>
    </tr>
    <tr>
      <th scope="row">Records</th>
      <td>Staffs</td>
      <td>Other Items</td>
    </tr>
  </table>
  <p><a href="visitor.php">view all visitors</a></p>
  <p><a href="craft.php">view all available craft</a> </p>
  <p><a href="art.php">view all available art</a></p>
  <p><a href="item.php">view other items</a></p>
  <p>
    
<p>
  <div class="ui-br" data-role="content">
    <div data-inline="true"></div>
    <div data-role="fieldcontain">
      <p>&nbsp;</p>
      <p>&nbsp;</p>
    </div>
  </div>
  <div data-role="footer">&copy; YUSIEFON 2020</div>
</div>
</p>
</body>
</html>