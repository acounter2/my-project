<?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "index.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "login.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($_SERVER['QUERY_STRING']) && strlen($_SERVER['QUERY_STRING']) > 0) 
  $MM_referrer .= "?" . $_SERVER['QUERY_STRING'];
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>wellcome to our museum | kindly feel free and lookaround</title>
<style type="text/css">
body,td,th {
	font-family: "Lucida Console", Monaco, monospace;
	color: #663300;
	text-align: center;
}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
}
a:active {
	text-decoration: none;
}
h1,h2,h3,h4,h5,h6 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
}
a {
	font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
	color: #CCC;
}
.I {
	font-style: italic;
}
vf {
	font-weight: bold;
}
#page p {
	font-size: large;
	font-weight: bold;
}
#page .ui-br div table {
	color: #66FFFF;
}
</style>
<link href="jquery-mobile/jquery.mobile.theme-1.0.min.css" rel="stylesheet" type="text/css" />
<link href="jquery-mobile/jquery.mobile.structure-1.0.min.css" rel="stylesheet" type="text/css" />
<script src="jquery-mobile/jquery-1.6.4.min.js" type="text/javascript"></script>
<script src="jquery-mobile/jquery.mobile-1.0.min.js" type="text/javascript"></script>
</head>

<body background="images/body-bg.gif">
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;

<div data-role="page" id="page">
  <div data-role="header">
    <h1>&nbsp;</h1>
    <h1><img src="images/new.jpg" width="1096" height="143" alt="m" /></h1>
    <h1><a href="index.php">HOMEPAGE</a> <a href="history.php">HISTORY OF KANO</a> <a href="collection.php">VIEW COLLECTION</a> <a href="gallery.php">CHECK GALLERY</a> <a href="about.php">ABOUT US</a></h1>
  </div>
 <table width="200" border="1" cellspacing="0" cellpadding="0">
      <tr>
        <th scope="col"><a href="<?php echo $logoutAction ?>">LOGOUT USER</a></th>
      </tr>
  </table>
  <p>Wellcome to our Collection Section  
    
  <p><img src="images/DMUSEUM.jpg" width="934" height="277" alt="JH" />
  <ul data-role="listview" data-inset="true" data-split-icon="info">
    <li><a href="art.php">
      <h3>Gidan Bagauda</h3>
      <p>Collection of Arts</p>
      <span class="ui-li-count">1</span>
      <p class="ui-li-aside">Aside</p>
    </a><a href="art.php">Default</a></li>
    <li><a href="craft.php">
      <h3>Filin Ado Bayero</h3>
      <p>Collection of Crafts</p>
      <span class="ui-li-count">2</span>
      <p class="ui-li-aside">LAst Collection 2018</p>
    </a><a href="craft.php">Default</a></li>
    <li><a href="item.php">
      <h3>Gidan Dabo ta Kano</h3>
      <p>Collection of other Items</p>
      <span class="ui-li-count">3</span>
      <p class="ui-li-aside">Aside</p>
    </a><a href="item.php">Default</a></li>
  </ul>
  <p>
  
  <p>
  <div class="ui-br" data-role="content">
    <div data-inline="true"></div>
    <div data-role="fieldcontain">
      <p>&nbsp;</p>
      <table width="203" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <th scope="row"><a href="3D.php">EXPLORE MUSEUM 3D</a></th>
        </tr>
        <tr>
          <th width="199" scope="col"><div class="ui-grid-a">
            <div class="ui-block-a"><img src="images/projects_but.png" alt="EXPLORE 3D" width="219" height="120" usemap="#Map" border="0" /></div>
            <div class="ui-block-b"></div>
          </div></th>
        </tr>
      </table>
      <p>&nbsp;</p>
    </div>
  </div>
  <div data-role="footer">&copy; YUSIEFON 2020</div>
</div>
</p>

<map name="Map" id="Map">
  <area shape="poly" coords="150,82" href="#" alt="EXPLORE" />
  <area shape="poly" coords="171,83,65,47,100,27,66,49,104,29,105,30,104,30,105,25,105,31,101,33,104,29" href="#" alt="EXPLORE" />
</map>
</body>
</html>