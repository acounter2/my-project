<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>wellcome to our museum | kindly feel free and lookaround</title>
<style type="text/css">
body,td,th {
	font-family: "Lucida Console", Monaco, monospace;
	color: #663300;
	text-align: center;
}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
}
a:active {
	text-decoration: none;
}
h1,h2,h3,h4,h5,h6 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
}
a {
	font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
	color: #CCC;
}
.I {
	font-style: italic;
}
vf {
	font-weight: bold;
}
#page p {
	font-size: large;
	font-weight: bold;
}
</style>
<link href="jquery-mobile/jquery.mobile.theme-1.0.min.css" rel="stylesheet" type="text/css" />
<link href="jquery-mobile/jquery.mobile.structure-1.0.min.css" rel="stylesheet" type="text/css" />
<script src="jquery-mobile/jquery-1.6.4.min.js" type="text/javascript"></script>
<script src="jquery-mobile/jquery.mobile-1.0.min.js" type="text/javascript"></script>
</head>

<body background="images/body-bg.gif">
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;

<div data-role="page" id="page">
  <div data-role="header">
    <h1>&nbsp;</h1>
    <h1><img src="images/new.jpg" width="1096" height="143" alt="m" /></h1>
    <h1><a href="index.php">HOMEPAGE</a> <a href="history.php">HISTORY OF KANO</a> <a href="collection.php">VIEW COLLECTION</a> <a href="gallery.php">CHECK GALLERY</a> <a href="about.php">ABOUT US</a></h1>
  </div>
  <p>Brief Details of Gidan Makama Museum Kano
  <p><img src="images/2015_11largeimg121_Nov_2015_234218113-580x387.jpg" width="228" height="163" alt="bh" />A museum is an institution that cares for (conserves) a collection of artifacts and other objects of scientific, artistic, cultural, or historical importance and makes them available for public viewing through exhibits that may be permanent or temporary. Most large museums are located in major cities throughout the world and more local ones exist in smaller cities, towns and even the countryside. Museums have varying aims, ranging from serving researchers and specialists to serving the general public. The continuing acceleration in the digitization of information, combined with the increasing capacity of digital information storage, is causing the traditional model of museums (i.e. as static “collections of collections” of three-dimensional specimens and artifacts) to expand to include virtual exhibits and high-resolution images of their collections for perusal, study, and exploration from any place with Internet. The city with the largest number of museums is Mexico City with over 128 museums. According to The World Museum Community, there are more than 55,000 museums in 202 countries.<br />
    The English &quot;museum&quot; comes from the Latin word, and is pluralized as &quot;museums&quot; (or rarely, &quot;musea&quot;). It is originally from the Ancient Greek Μουσεῖον (Mouseion), which denotes a place or temple dedicated to the Muses (the patron divinities in Greek mythology of the arts), and hence a building set apart for study and the arts, especially the Musaeum (institute) for philosophy and research at Alexandria by Ptolemy I Soter about 280 BCE. The first museum/library is considered to be the one of Plato in Athens. However, Pausanias gives another place called &quot;Museum,&quot; namely a small hill in Classical Athens opposite the Akropolis. The hill was called Mouseion after Mousaious, a man who used to sing on the hill and died there of old age and was subsequently buried there as well.
  <p><br />
    At the background of study is the Gidan Makama Museum Kano, Kano state. Kano State is a state in the north western part of Nigeria. The capital is Kano the major Commercial city, Gidan Makama Museum Kano or Kano Museum is a museum in Kano, Nigeria. This building served as temporary palace of Kano before the current palace Gidan Rumfa was constructed in the 15th century[1] The museum has a significant collections of arts, crafts and items of historic interest related to the Kano area.[2]Located in a 15th-century historical building, which is recognised as a National Monument by the Government of Nigeria. The museum is divided into 11 galleries, each with their own centre of focus. Galleries include the Zaure or the main entrance hall with displays of traditional materials, city walls and maps of Kano, the history of statehood, Kano in the 19th century, the Civil War, economy, industry and music. <br />
    One of its museums is located at Along Emir Palace , Kano state. That region is predominantly known as Kanawan Dabo. This museum forms the background of our study. The program under development adopts the procedure in that museum, virtually all the modules of the development will be tailored to the national museum of colonial history Kano.<br />
  The purpose of the museums is to collect, preserve, interpret, and display items of cultural, artistic, or scientific significance for the education of the public. The purpose can also depend on one’s point of view. To a family looking for entertainment on a Sunday afternoon, a trip to the local history museum could be a fun, and enlightening way to spend the day. To city leaders, a healthy museum community can be seen as a gauge of the economic health of a city, and a way to increase the sophistication of its inhabitants. To a museum professional, a museum might be seen as a way to educate the public about the museum’s mission, such as civil rights or environmentalism.</p>
  <p></p>
  <p>
  <div class="ui-br" data-role="content">
    <div data-inline="true"></div>
    <div data-role="fieldcontain">
      <p>&nbsp;</p>
      <p>&nbsp;</p>
    </div>
  </div>
  <div data-role="footer">&copy; YUSIEFON 2020</div>
</div>
</p>
</body>
</html>