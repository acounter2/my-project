<?php require_once('Connections/MUSEUM.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form2")) {
  $insertSQL = sprintf("INSERT INTO register (user_id, username, password, email, mobile, state_of_resid, occupation, reason_visit) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['user_id'], "int"),
                       GetSQLValueString($_POST['username'], "text"),
                       GetSQLValueString($_POST['password'], "text"),
                       GetSQLValueString($_POST['email'], "text"),
                       GetSQLValueString($_POST['mobile'], "int"),
                       GetSQLValueString($_POST['state_of_resid'], "text"),
                       GetSQLValueString($_POST['occupation'], "text"),
                       GetSQLValueString($_POST['reason_visit'], "text"));

  mysql_select_db($database_MUSEUM, $MUSEUM);
  $Result1 = mysql_query($insertSQL, $MUSEUM) or die(mysql_error());

  $insertGoTo = "museum.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}

mysql_select_db($database_MUSEUM, $MUSEUM);
$query_Recordset1 = "SELECT username, password, email, mobile, state_of_resid, occupation, reason_visit FROM register";
$Recordset1 = mysql_query($query_Recordset1, $MUSEUM) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
$query_Recordset1 = "SELECT * FROM register";
$Recordset1 = mysql_query($query_Recordset1, $MUSEUM) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>new visitor can register here</title>
<style type="text/css">
body,td,th {
	font-family: "Lucida Console", Monaco, monospace;
	color: #000000;
	text-align: center;
}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
}
a:active {
	text-decoration: none;
	color: #933;
	font-family: "Comic Sans MS", cursive;
	font-weight: bold;
}
h1,h2,h3,h4,h5,h6 {
	font-family: Arial, Helvetica, sans-serif;
}
a {
	font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
	color: #CCC;
}
.hj {
	color: #660000;
}
.uy {
	color: #FF0000;
}
</style>
</head>

<body background="images/body-bg.gif">
<p>&nbsp;</p>
<p>&nbsp;</p>
<p><img src="images/new.jpg" width="1327" height="200" alt="m" /></p>
<p><a href="index.php">HOMEPAGE</a> <a href="history.php">HISTORY OF KANO</a> <a href="collection.php">VIEW COLLECTION</a> <a href="gallery.php">CHECK GALLERY</a> <a href="about.php">ABOUT US</a></p>
<table width="672" height="260" border="0" align="center" cellpadding="0" cellspacing="0" dir="ltr">
  <tr>
    <th height="154" bgcolor="#FFFFFF" scope="col"><strong><img src="images/users.png" width="130" height="134" alt="adm2" /><img src="images/adminuser.png" width="128" height="128" alt="u" /><span class="hj">|</span><img src="images/kuj.png" width="99" height="117" alt="bg" /></strong><img src="images/services_but.png" width="125" height="134" alt="adm" /></th>
  </tr>
  <tr>
    <th width="800" height="106" bgcolor="#CCCCCC" scope="col"><fieldset>
      <p class="uy">username already exist, please change username and signup!!</p>
<legend></legend><form action="<?php echo $editFormAction; ?>" method="post" name="form2" id="form2">
        <label><table align="center">
          <tr valign="baseline">
            <td nowrap="nowrap" align="right">Visitorname:</td>
            <td><input type="text" name="username" value="" size="32" /></td>
          </tr>
          <tr valign="baseline">
            <td nowrap="nowrap" align="right">Password:</td>
            <td><input type="password" name="password" value="" size="32" /></td>
          </tr>
          <tr valign="baseline">
            <td nowrap="nowrap" align="right">Email:</td>
            <td><input type="text" name="email" value="" size="32" /></td>
          </tr>
          <tr valign="baseline">
            <td nowrap="nowrap" align="right">Mobile:</td>
            <td><input type="text" name="mobile" value="" size="32" /></td>
          </tr>
          <tr valign="baseline">
            <td nowrap="nowrap" align="right">State_of_resident:</td>
            <td><input type="text" name="state_of_resid" value="" size="32" /></td>
          </tr>
          <tr valign="baseline">
            <td nowrap="nowrap" align="right">Occupation:</td>
            <td><input type="text" name="occupation" value="" size="32" /></td>
          </tr>
          <tr valign="baseline">
            <td nowrap="nowrap" align="right">Reason_visit:</td>
            <td><input type="text" name="reason_visit" value="" size="32" /></td>
          </tr>
          <tr valign="baseline">
            <td nowrap="nowrap" align="right">&nbsp;</td>
            <td><input type="submit" value="Add Visitor" /> 
            or <a href="login.php"><font color= red >Login</a></td>
          </tr>
        </table></label>
        <input type="hidden" name="MM_insert" value="form2" />
      </form></fieldset>
    <p>&nbsp;</p></th>
  </tr>
</table>
</body>
</html>
<?php
mysql_free_result($Recordset1);
?>
