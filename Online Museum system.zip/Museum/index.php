<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>wellcome to our museum | kindly feel free and lookaround</title>
<style type="text/css">
body,td,th {
	font-family: "Lucida Console", Monaco, monospace;
	color: #D6D6D6;
	text-align: center;
}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
}
a:active {
	text-decoration: none;
}
h1,h2,h3,h4,h5,h6 {
	font-family: Arial, Helvetica, sans-serif;
}
a {
	font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
	color: #CCC;
}
</style>
</head>

<body background="images/body-bg.gif">
<p>&nbsp;</p>
<p><img src="images/new.jpg" width="1327" height="215" alt="m" /></p>
<p><a href="index.php">HOMEPAGE</a> <a href="history.php">HISTORY OF KANO</a> <a href="login.php">VIEW COLLECTION</a> <a href="gallery.php">CHECK GALLERY</a> <a href="about.php">ABOUT US</a></p>
<table width="800" height="150" border="0" align="center" cellpadding="0" cellspacing="0" dir="ltr">
  <tr>
    <th width="800" height="300" bgcolor="#400000" scope="col"><a href="museum.php"><img src="images/Kano-Museum.jpg" alt="dmuse" width="800" height="289" usemap="#Map" border="0" /></a></th>
  </tr>
</table>

<map name="Map" id="Map">
  <area shape="rect" coords="130,70,280,179" href="#" alt="CHECJ" />
  <area shape="rect" coords="290,240,440,269" href="index.php" target="new" alt="Visit our museum" />
</map>
</body>
</html>