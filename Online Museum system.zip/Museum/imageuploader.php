<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php
if (isset($_POST['btn_uplo']))
{
	$id=$_POST['hf_uname'];
	move_uploaded_file($_FILES["file"] ["tmp_name"],"imageArt/".$id.".png");
	
	echo "successfully uploaded!";
}
?>
<form action="" method="post" enctype="multipart/form-data" name="form1" id="form1">
  <label for="file">select picture</label>
  <input type="file" name="file" id="file" />
  <input type="submit" name="btn_upto" id="btn_uplo" value="upload" />
  <input name="hf_uname" type="hidden" id="hf_uname" value="<?php echo $_POST ['hf_uname']?>" />
</form>
</body>
</html>