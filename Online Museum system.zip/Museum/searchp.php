<?php require_once('Connections/MUSEUM.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$currentPage = $_SERVER["PHP_SELF"];

$maxRows_Recordset1 = 1;
$pageNum_Recordset1 = 0;
if (isset($_GET['pageNum_Recordset1'])) {
  $pageNum_Recordset1 = $_GET['pageNum_Recordset1'];
}
$startRow_Recordset1 = $pageNum_Recordset1 * $maxRows_Recordset1;

$colname_Recordset1 = "-1";
if (isset($_POST['search'])) {
  $colname_Recordset1 = $_POST['search'];
}
mysql_select_db($database_MUSEUM, $MUSEUM);
$query_Recordset1 = sprintf("SELECT * FROM register WHERE username = %s", GetSQLValueString($colname_Recordset1, "text"));
$query_limit_Recordset1 = sprintf("%s LIMIT %d, %d", $query_Recordset1, $startRow_Recordset1, $maxRows_Recordset1);
$Recordset1 = mysql_query($query_limit_Recordset1, $MUSEUM) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);

if (isset($_GET['totalRows_Recordset1'])) {
  $totalRows_Recordset1 = $_GET['totalRows_Recordset1'];
} else {
  $all_Recordset1 = mysql_query($query_Recordset1);
  $totalRows_Recordset1 = mysql_num_rows($all_Recordset1);
}
$totalPages_Recordset1 = ceil($totalRows_Recordset1/$maxRows_Recordset1)-1;

$queryString_Recordset1 = "";
if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_Recordset1") == false && 
        stristr($param, "totalRows_Recordset1") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_Recordset1 = "&" . htmlentities(implode("&", $newParams));
  }
}
$queryString_Recordset1 = sprintf("&totalRows_Recordset1=%d%s", $totalRows_Recordset1, $queryString_Recordset1);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="jquery-mobile/jquery.mobile.theme-1.0.min.css" rel="stylesheet" type="text/css" />
<link href="jquery-mobile/jquery.mobile.structure-1.0.min.css" rel="stylesheet" type="text/css" />
<script src="jquery-mobile/jquery-1.6.4.min.js" type="text/javascript"></script>
<script src="jquery-mobile/jquery.mobile-1.0.min.js" type="text/javascript"></script>
</head>

<body>
<form id="form1" name="form1" method="post" action="">
  <div data-role="page" id="page5">
    <div data-role="header">
      <h1>Visitor's Records</h1>
    </div>
    <div data-role="content">
      <?php if ($totalRows_Recordset1 > 0) { // Show if recordset not empty ?>
  <table width="378" border="1" align="center" cellpadding="2" cellspacing="1">
    <tr>
      <th scope="col">Visitor Identity</th>
      <th scope="col"><?php echo $row_Recordset1['user_id']; ?></th>
      </tr>
    <tr>
      <th scope="row">Nickname</th>
      <td><?php echo $row_Recordset1['username']; ?></td>
      </tr>
    <tr>
      <th scope="row">Occupation</th>
      <td><?php echo $row_Recordset1['occupation']; ?></td>
      </tr>
    <tr>
      <th scope="row">Email</th>
      <td><?php echo $row_Recordset1['email']; ?></td>
      </tr>
    <tr>
      <th scope="row">Contact Number</th>
      <td><?php echo $row_Recordset1['mobile']; ?></td>
      </tr>
    <tr>
      <th scope="row">State of Residencee</th>
      <td><?php echo $row_Recordset1['state_of_resid']; ?></td>
      </tr>
  </table>
  <br />
  <br />
  <br />
  <br />
<?php } // Show if recordset not empty ?>
<a href="<?php printf("%s?pageNum_Recordset1=%d%s", $currentPage, min($totalPages_Recordset1, $pageNum_Recordset1 + 1), $queryString_Recordset1); ?>">Next</a></div>
    <div data-role="footer">
      <?php if ($totalRows_Recordset1 == 0) { // Show if recordset empty ?>
  <h2>Sorry no records found, eithier the user is not yet registered or retype the username again appropriately and try relogin!</h2>
  <?php } // Show if recordset empty ?>
    </div>
  </div>
</form>
</body>
</html>
<?php
mysql_free_result($Recordset1);
?>
