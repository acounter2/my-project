<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_MUSEUM = "127.0.0.1";
$database_MUSEUM = "museum";
$username_MUSEUM = "root";
$password_MUSEUM = "";
$MUSEUM = mysql_pconnect($hostname_MUSEUM, $username_MUSEUM, $password_MUSEUM) or trigger_error(mysql_error(),E_USER_ERROR); 
?>