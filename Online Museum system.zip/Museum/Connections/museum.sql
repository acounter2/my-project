-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 10, 2020 at 08:17 PM
-- Server version: 5.5.16
-- PHP Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `museum`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `admin` varchar(25) NOT NULL,
  `password` int(15) NOT NULL,
  KEY `admin` (`admin`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin`, `password`) VALUES
('admin', 12345),
('yusuf', 12345);

-- --------------------------------------------------------

--
-- Table structure for table `art`
--

CREATE TABLE IF NOT EXISTS `art` (
  `art_id` int(15) NOT NULL AUTO_INCREMENT,
  `art_title` varchar(25) NOT NULL,
  `art_name` varchar(25) NOT NULL,
  `art_origin` varchar(25) NOT NULL,
  `art_discover` date NOT NULL,
  `art_uses` varchar(50) NOT NULL,
  PRIMARY KEY (`art_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `art`
--

INSERT INTO `art` (`art_id`, `art_title`, `art_name`, `art_origin`, `art_discover`, `art_uses`) VALUES
(1, 'koros drums', 'drum', 'karaye emirate', '0000-00-00', 'dancing');

-- --------------------------------------------------------

--
-- Table structure for table `craft`
--

CREATE TABLE IF NOT EXISTS `craft` (
  `craft_id` int(15) NOT NULL AUTO_INCREMENT,
  `craft_title` varchar(25) NOT NULL,
  `craft_name` varchar(25) NOT NULL,
  `craft_origin` varchar(25) NOT NULL,
  `carft_year` date NOT NULL,
  `craft_uses` varchar(50) NOT NULL,
  PRIMARY KEY (`craft_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `craft`
--

INSERT INTO `craft` (`craft_id`, `craft_title`, `craft_name`, `craft_origin`, `carft_year`, `craft_uses`) VALUES
(2, 'kwano manya', 'bowl', 'zinder', '1910-01-02', 'fetching');

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

CREATE TABLE IF NOT EXISTS `item` (
  `it_id` int(15) NOT NULL AUTO_INCREMENT,
  `it_name` varchar(30) NOT NULL,
  `it_origin` varchar(20) NOT NULL,
  `it_year` date NOT NULL,
  `it_tiltle` varchar(25) NOT NULL,
  `it_discover` varchar(25) NOT NULL,
  PRIMARY KEY (`it_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='all museum collection store' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE IF NOT EXISTS `register` (
  `user_id` int(15) NOT NULL AUTO_INCREMENT,
  `username` varchar(15) NOT NULL,
  `password` varchar(15) NOT NULL,
  `email` varchar(15) NOT NULL,
  `mobile` int(11) NOT NULL,
  `state_of_resid` varchar(25) NOT NULL,
  `occupation` varchar(25) NOT NULL,
  `reason_visit` varchar(50) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`user_id`, `username`, `password`, `email`, `mobile`, `state_of_resid`, `occupation`, `reason_visit`) VALUES
(4, 'yusuf', '12345', '55', 55, '55', '55', '55'),
(6, 'abba', '12345', 'tr', 0, 'oyo', 'sw', 'ffff');

-- --------------------------------------------------------

--
-- Table structure for table `timetable`
--

CREATE TABLE IF NOT EXISTS `timetable` (
  `t_id` int(25) NOT NULL AUTO_INCREMENT,
  `t_monday` varchar(25) NOT NULL,
  `t_tuesday` varchar(25) NOT NULL,
  `t_wednesday` varchar(25) NOT NULL,
  `t_thursday` varchar(25) NOT NULL,
  `t_friday` varchar(25) NOT NULL,
  `t_saturday` varchar(25) NOT NULL,
  `t_sunday` varchar(25) NOT NULL,
  PRIMARY KEY (`t_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `t_calendar`
--

CREATE TABLE IF NOT EXISTS `t_calendar` (
  `c_id` int(6) NOT NULL AUTO_INCREMENT,
  `C_monday` varchar(25) NOT NULL,
  `c_tuesday` varchar(25) NOT NULL,
  `c_wednesday` varchar(25) NOT NULL,
  `C_thursday` varchar(25) NOT NULL,
  `c_friday` varchar(25) NOT NULL,
  `c_saturday` varchar(25) NOT NULL,
  `csunday` varchar(25) NOT NULL,
  PRIMARY KEY (`c_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
