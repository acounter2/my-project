<?php require_once('Connections/MUSEUM.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_Recordset1 = "-1";
if (isset($_POST['search'])) {
  $colname_Recordset1 = $_POST['search'];
}
mysql_select_db($database_MUSEUM, $MUSEUM);
$query_Recordset1 = sprintf("SELECT * FROM art WHERE art_name = %s", GetSQLValueString($colname_Recordset1, "text"));
$Recordset1 = mysql_query($query_Recordset1, $MUSEUM) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="jquery-mobile/jquery.mobile.theme-1.0.min.css" rel="stylesheet" type="text/css" />
<link href="jquery-mobile/jquery.mobile.structure-1.0.min.css" rel="stylesheet" type="text/css" />
<script src="jquery-mobile/jquery-1.6.4.min.js" type="text/javascript"></script>
<script src="jquery-mobile/jquery.mobile-1.0.min.js" type="text/javascript"></script>
</head>

<body>
<form id="form1" name="form1" method="post" action="">
  <div data-role="page" id="page5">
    <div data-role="header">
      <h1>Visitor's Records</h1>
    </div>
    <div data-role="content">
      <?php if ($totalRows_Recordset1 > 0) { // Show if recordset not empty ?>
  <table width="378" border="1" align="center" cellpadding="2" cellspacing="1">
    <tr>
      <th scope="col">Art Identity</th>
      <th scope="col"><?php echo $row_Recordset1['art_id']; ?></th>
      </tr>
    <tr>
      <th scope="row">Title</th>
      <td><?php echo $row_Recordset1['art_title']; ?></td>
      </tr>
    <tr>
      <th scope="row">Art Name</th>
      <td><?php echo $row_Recordset1['art_name']; ?></td>
      </tr>
    <tr>
      <th scope="row">Origin</th>
      <td><?php echo $row_Recordset1['art_origin']; ?></td>
      </tr>
    <tr>
      <th scope="row">Discover</th>
      <td><?php echo $row_Recordset1['art_discover']; ?></td>
      </tr>
    <tr>
      <th scope="row">Uses</th>
      <td><?php echo $row_Recordset1['art_uses']; ?></td>
      </tr>
  </table>
  <br />
  <br />
  <br />
  <br />
<?php } // Show if recordset not empty ?>
Next    </div>
    <div data-role="footer">
      <?php if ($totalRows_Recordset1 == 0) { // Show if recordset empty ?>
  <h2>Sorry no records found, eithier the user is not yet registered or retype the username again appropriately and try relogin!</h2>
  <?php } // Show if recordset empty ?>
    </div>
  </div>
</form>
</body>
</html>
<?php
mysql_free_result($Recordset1);
?>
