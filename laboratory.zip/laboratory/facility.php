<?php require_once('Connections/laboratory.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_laboratory, $laboratory);
$query_Recordset1 = "SELECT * FROM facility_equip";
$Recordset1 = mysql_query($query_Recordset1, $laboratory) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);$colname_Recordset1 = "-1";
if (isset($_POST['search'])) {
  $colname_Recordset1 = $_POST['search'];
}
mysql_select_db($database_laboratory, $laboratory);
$query_Recordset1 = sprintf("SELECT * FROM facility_equip WHERE facility_name = %s", GetSQLValueString($colname_Recordset1, "text"));
$Recordset1 = mysql_query($query_Recordset1, $laboratory) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
.IU {
	color: #F00;
	font-weight: bold;
	font-style: italic;
}
</style>
</head>

<body>
<?php if ($totalRows_Recordset1 > 0) { // Show if recordset not empty ?>
  <table width="429" border="1" align="center" cellpadding="2" cellspacing="5">
    <caption>
      FACILITY SEARCH RESULT
    </caption>
    <tr>
      <th width="151" scope="col">QUERY</th>
      <th width="249" scope="col">RESULT FOUND</th>
    </tr>
    <tr>
      <td>FACILITY ID</td>
      <td><?php echo $row_Recordset1['facility_id']; ?></td>
    </tr>
    <tr>
      <td>FACILITY NAME</td>
      <td><?php echo $row_Recordset1['facility_name']; ?></td>
    </tr>
    <tr>
      <td>PURPOSE</td>
      <td><?php echo $row_Recordset1['facility_purpose']; ?></td>
    </tr>
    <tr>
      <td>PRODUCTION</td>
      <td><?php echo $row_Recordset1['facility_prod']; ?></td>
    </tr>
    <tr>
      <td>YEAR</td>
      <td><?php echo $row_Recordset1['year']; ?></td>
    </tr>
  </table>
  <?php } // Show if recordset not empty ?>
<?php if ($totalRows_Recordset1 == 0) { // Show if recordset empty ?>
  <p class="IU">SORRY!!! NO RECORD FOUND PLEASE GO BACK AND RESEARCH.</p>
  <?php } // Show if recordset empty ?>
</body>
</html>
<?php
mysql_free_result($Recordset1);
?>
