<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>MediStop Laboratory services</title>
<link href="jquery-mobile/jquery.mobile-1.0.min.css" rel="stylesheet" type="text/css" />
<style type="text/css">
#ONE div p {
	font-weight: bold;
}
#ONE div p {
	color: #603;
}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: underline;
}
a:active {
	text-decoration: none;
}
#apDiv2 {
	position: absolute;
	width: 200px;
	height: 100px;
	z-index: 0;
	background-image: url(image/LabImage/mark.jpg);
	background-color: #FFFFFF;
	overflow: visible;
	visibility: visible;
	clip: rect(20,20,20,20);
	left: 9px;
	top: 369px;
}
#ONE div #apDiv2 strong {
	color: #C30;
}
</style>
<script src="jquery-mobile/jquery-1.6.4.min.js" type="text/javascript"></script>
<script src="jquery-mobile/jquery.mobile-1.0.min.js" type="text/javascript"></script>
</head>

<body>
<div data-role="page" id="ONE">
  <div data-role="header">
    <h1><img src="image/img.png" width="985" height="114" alt="im" /></h1>
  </div>
  <div data-role="content">
    <table width="353" border="1" cellpadding="4" cellspacing="4" summary="as the says "health="health" is="is" essential="essential"" your well="well" being="being" our="our" priority.!="priority.!"

a="a" system="system" with="with" features="features" that="that" support="support" modern="modern" laboratory="laboratory"'s operations.="operations." it="it" software="software" records,="records," manages="manages" and="and" stores="stores" data="data" for="for" clinical="clinical" laboratories....="laboratories...."">
      <caption>
        <em><strong>Medistop Laboratory Service Calender</strong></em><br />
      </caption>
      <tr>
        <th width="93" scope="col">DAYS</th>
        <th width="122" scope="col">HOURS</th>
      </tr>
      <tr>
        <th scope="row">SAT - SUN</th>
        <td>10:00 AM - 6:00PM</td>
        <td width="55"><img src="image/50_64x64.png" width="55" height="29" alt="K" /></td>
      </tr>
      <tr>
        <th scope="row">MON - FRI</th>
        <td>8:00AM - 10:00PM</td>
        <td><img src="image/50_64x64.png" width="55" height="29" alt="K" /></td>
      </tr>
    </table>
    
    <p>
    <div id="apDiv2"><strong>LOGIN Succesfully! you are welcome! </strong></div>
    <p><RIGHT>CLICK TO VIEW TODAY'S HEALTH TIPS....</RIGHT>
    <table width="300" align="center" cellpadding="4">
  <tr>
    <th scope="col"><a href="labtest2.php"><img src="image/LabImage/blood1.jpg" width="366" height="200" alt="mjh" /></a></th>
    <th scope="col"><img src="image/LabImage/lab1.jpg" width="366" height="200" /></th>
  </tr>
  <tr>
    <th scope="row"><a href="labtest2.php">Go for testing</a><a href="searchfaci.php"></a></th>
    <th scope="row"><a href="searchfaci.php">Search for Lab Equipment</a></th>
  </tr>
</table></div>
  <div data-role="footer">
    <h4>COPYRIGHT YUSIEFSON 2020<BR />all right reserved.  </h4>
  </div>
</div>
<p>
<p>
<p>
<p>
</body>
</html>