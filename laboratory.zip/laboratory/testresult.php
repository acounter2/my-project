<?php require_once('Connections/laboratory.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$maxRows_Recordset1 = 10;
$pageNum_Recordset1 = 0;
if (isset($_GET['pageNum_Recordset1'])) {
  $pageNum_Recordset1 = $_GET['pageNum_Recordset1'];
}
$startRow_Recordset1 = $pageNum_Recordset1 * $maxRows_Recordset1;

mysql_select_db($database_laboratory, $laboratory);
$query_Recordset1 = "SELECT * FROM lab_test";
$query_limit_Recordset1 = sprintf("%s LIMIT %d, %d", $query_Recordset1, $startRow_Recordset1, $maxRows_Recordset1);
$Recordset1 = mysql_query($query_limit_Recordset1, $laboratory) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);

if (isset($_GET['totalRows_Recordset1'])) {
  $totalRows_Recordset1 = $_GET['totalRows_Recordset1'];
} else {
  $all_Recordset1 = mysql_query($query_Recordset1);
  $totalRows_Recordset1 = mysql_num_rows($all_Recordset1);
}
$totalPages_Recordset1 = ceil($totalRows_Recordset1/$maxRows_Recordset1)-1;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>MediStop Laboratory services</title>
<link href="jquery-mobile/jquery.mobile-1.0.min.css" rel="stylesheet" type="text/css" />
<style type="text/css">
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: underline;
}
a:active {
	text-decoration: none;
}
</style>
<script src="jquery-mobile/jquery-1.6.4.min.js" type="text/javascript"></script>
<script src="jquery-mobile/jquery.mobile-1.0.min.js" type="text/javascript"></script>
</head>

<body>
<div data-role="page" id="ONE">
  <div data-role="header">
    <h1><img src="image/img.png" width="985" height="114" alt="im" /></h1>
  </div>
  <div data-role="content">
    <table width="353" border="1" cellpadding="4" cellspacing="4" summary="as the says "health="health" is="is" essential="essential"" your well="well" being="being" our="our" priority.!="priority.!"

a="a" system="system" with="with" features="features" that="that" support="support" modern="modern" laboratory="laboratory"'s operations.="operations." it="it" software="software" records,="records," manages="manages" and="and" stores="stores" data="data" for="for" clinical="clinical" laboratories....="laboratories...."">
      <caption>
        <em><strong>Medistop Laboratory Service Calender</strong></em><br />
      </caption>
      <tr>
        <th width="93" scope="col">DAYS</th>
        <th width="122" scope="col">HOURS</th>
      </tr>
      <tr>
        <th scope="row">SAT - SUN</th>
        <td>10:00 AM - 6:00PM</td>
        <td width="55"><img src="image/50_64x64.png" width="55" height="29" alt="K" /></td>
      </tr>
      <tr>
        <th scope="row">MON - FRI</th>
        <td>8:00AM - 10:00PM</td>
        <td><img src="image/50_64x64.png" width="55" height="29" alt="K" /></td>
      </tr>
    </table>
    
    <BR />
    <fieldset>
      <legend>all lab test list here</legend>
    </fieldset>
    <p>&nbsp;</p>
    <table border="0" cellpadding="1" cellspacing="2">
      <tr>
        <td bgcolor="#3399CC">test_id</td>
        <td bgcolor="#3399CC">test_name</td>
        <td bgcolor="#3399CC">test_group</td>
        <td bgcolor="#3399CC">test_sub_group</td>
        <td bgcolor="#3399CC">price</td>
        <td bgcolor="#3399CC">unit</td>
        <td bgcolor="#3399CC">resultday</td>
      </tr>
      <?php do { ?>
        <tr>
          <td bgcolor="#00FFCC"><?php echo $row_Recordset1['test_id']; ?></td>
          <td bgcolor="#00FFCC"><?php echo $row_Recordset1['test_name']; ?></td>
          <td bgcolor="#00FFCC"><?php echo $row_Recordset1['test_group']; ?></td>
          <td bgcolor="#00FFCC"><?php echo $row_Recordset1['test_sub_group']; ?></td>
          <td bgcolor="#00FFCC"><?php echo $row_Recordset1['price']; ?></td>
          <td bgcolor="#00FFCC"><?php echo $row_Recordset1['unit']; ?></td>
          <td bgcolor="#00FFCC"><?php echo $row_Recordset1['resultday']; ?></td>
        </tr>
        <?php } while ($row_Recordset1 = mysql_fetch_assoc($Recordset1)); ?>
    </table>
<p><a href="labtest2.php">Add new Test</a></p>
<p><a href="searchlabtest.php">Search to Print test result</a></p>
<p>
<p>
</div>
  <div data-role="footer">
    <h4>COPYRIGHT YUSIEFSON 2020<BR />all right reserved.  </h4>
  </div>
</div>
<p>
<p>
<p>
<p>
</body>
</html>
<?php
mysql_free_result($Recordset1);
?>
