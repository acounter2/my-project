-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 24, 2020 at 03:42 PM
-- Server version: 5.5.16
-- PHP Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `laboratory`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `admin_log` varchar(15) NOT NULL,
  `adm_pwd` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_log`, `adm_pwd`) VALUES
('medistop', 12345),
('medistop', 12345),
('medistop', 54321),
('medistop', 54321),
('medistop', 12345),
('medistop', 12345),
('medistop', 12345),
('medistop', 1235),
('medistop', 12345),
('medistop', 12345),
('medistop', 12345);

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE IF NOT EXISTS `doctor` (
  `dtr_id` int(15) NOT NULL AUTO_INCREMENT,
  `dtr_name` varchar(25) NOT NULL,
  `dtr_specific` varchar(25) NOT NULL,
  `dtr_level` varchar(25) NOT NULL,
  `dtr_last_opr` varchar(30) NOT NULL,
  `dctr_age` int(15) NOT NULL,
  `dctr_salary` int(15) NOT NULL,
  PRIMARY KEY (`dtr_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`dtr_id`, `dtr_name`, `dtr_specific`, `dtr_level`, `dtr_last_opr`, `dctr_age`, `dctr_salary`) VALUES
(1, 'abdulashid', 'surgery', 'proffesional', 'disjoint', 54, 1000000),
(3, 'bello', 'orthopaedic', 'apprentice', 'abortion', 29, 50000);

-- --------------------------------------------------------

--
-- Table structure for table `drugs`
--

CREATE TABLE IF NOT EXISTS `drugs` (
  `drg_id` int(15) NOT NULL AUTO_INCREMENT,
  `drg_name` varchar(15) NOT NULL,
  `drg_prescription` varchar(25) NOT NULL,
  `drg-usage` varchar(30) NOT NULL,
  PRIMARY KEY (`drg_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `facility_equip`
--

CREATE TABLE IF NOT EXISTS `facility_equip` (
  `facility_id` int(25) NOT NULL AUTO_INCREMENT,
  `facility_name` text NOT NULL,
  `facility_purpose` varchar(30) NOT NULL,
  `facility_prod` varchar(30) NOT NULL,
  `year` varchar(25) NOT NULL,
  PRIMARY KEY (`facility_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=125113 ;

--
-- Dumping data for table `facility_equip`
--

INSERT INTO `facility_equip` (`facility_id`, `facility_name`, `facility_purpose`, `facility_prod`, `year`) VALUES
(125111, 'TEXTING TUBE', 'FILTERING', 'MACMEDICINE', '2009'),
(125112, 'syringe', 'injecting', 'losangeles', '2019');

-- --------------------------------------------------------

--
-- Table structure for table `lab_test`
--

CREATE TABLE IF NOT EXISTS `lab_test` (
  `test_id` int(15) NOT NULL AUTO_INCREMENT,
  `test_name` varchar(25) NOT NULL,
  `test_group` varchar(25) NOT NULL,
  `test_sub_group` varchar(25) NOT NULL,
  `price` int(25) NOT NULL,
  `unit` int(25) NOT NULL,
  `resultday` varchar(25) NOT NULL,
  PRIMARY KEY (`test_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `nurse`
--

CREATE TABLE IF NOT EXISTS `nurse` (
  `nrs_id` int(15) NOT NULL AUTO_INCREMENT,
  `nrs_name` varchar(20) NOT NULL,
  `nurse_dprt` varchar(25) NOT NULL,
  `attached` varchar(30) NOT NULL,
  `record` varchar(40) NOT NULL,
  PRIMARY KEY (`nrs_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `nurse`
--

INSERT INTO `nurse` (`nrs_id`, `nrs_name`, `nurse_dprt`, `attached`, `record`) VALUES
(2, 'joy', 'nursing', 'docBayor', 'excellent');

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE IF NOT EXISTS `patients` (
  `patience_id` int(15) NOT NULL AUTO_INCREMENT,
  `patience_name` varchar(25) NOT NULL,
  `patience_no` int(25) NOT NULL,
  `sex` varchar(25) NOT NULL,
  `age` int(15) NOT NULL,
  `reg_date` date NOT NULL,
  `blood_group` varchar(25) NOT NULL,
  `genotype` varchar(25) NOT NULL,
  PRIMARY KEY (`patience_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=234117 ;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`patience_id`, `patience_name`, `patience_no`, `sex`, `age`, `reg_date`, `blood_group`, `genotype`) VALUES
(234111, 'yusuf', 812565222, 'male', 0, '0000-00-00', 'o-', 'ac'),
(234112, 'zainabu', 54477777, 'female', 0, '0000-00-00', 'b plus', 'ab'),
(234113, 'john', 81111, 'm', 14, '0000-00-00', 'o', 'a'),
(234114, 'ada', 6666, 'f', 3, '0000-00-00', 'o', 'n'),
(234116, 'adamu', 222, '2', 2, '0000-00-00', 'o', 'n');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
