<?php
session_start();
echo $_SESSION['user_id']
?>

