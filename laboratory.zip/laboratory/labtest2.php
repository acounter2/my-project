<?php require_once('Connections/laboratory.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form2")) {
  $insertSQL = sprintf("INSERT INTO lab_test (test_name, test_group, test_sub_group, price, unit, resultday) VALUES (%s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['test_name'], "text"),
                       GetSQLValueString($_POST['test_group'], "text"),
                       GetSQLValueString($_POST['test_sub_group'], "text"),
                       GetSQLValueString($_POST['price'], "int"),
                       GetSQLValueString($_POST['unit'], "int"),
                       GetSQLValueString($_POST['resultday'], "text"));

  mysql_select_db($database_laboratory, $laboratory);
  $Result1 = mysql_query($insertSQL, $laboratory) or die(mysql_error());

  $insertGoTo = "testresult.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}

mysql_select_db($database_laboratory, $laboratory);
$query_Recordset1 = "SELECT * FROM lab_test";
$Recordset1 = mysql_query($query_Recordset1, $laboratory) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>MediStop Lab TEST</title>
<style type="text/css">
#apDiv1 {
	position: absolute;
	width: 177px;
	height: 115px;
	z-index: 1;
	background-image: url(image/LabImage/urine1.jpg);
	font-size: 10px;
}
</style>
<link href="jquery-mobile/jquery.mobile.theme-1.0.min.css" rel="stylesheet" type="text/css" />
<link href="jquery-mobile/jquery.mobile.structure-1.0.min.css" rel="stylesheet" type="text/css" />
<style type="text/css">
#apDiv2 {
	position: absolute;
	width: 171px;
	height: 115px;
	z-index: 1;
	left: 1155px;
	top: 192px;
	background-color: #33FF66;
	background-image: url(image/LabImage/Picture2.jpg);
	font-size: 9px;
}
#HYT div #form2 #apDiv2 p {
	font-weight: bold;
	text-align: center;
}
#apDiv3 {	position: absolute;
	width: 200px;
	height: 115px;
	z-index: 1;
	background-image: url(image/LabImage/urine1.jpg);
}
#apDiv4 {
	position: absolute;
	width: 200px;
	height: 115px;
	z-index: 1;
	background-image: url(image/LabImage/urine1.jpg);
	left: 324px;
	top: 323px;
}
#HYT div #form2 table tr td strong {
	text-align: center;
}
.jh {
	font-weight: bold;
}
#HYT div #form2 table tr td {
	font-weight: bold;
}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: underline;
}
a:active {
	text-decoration: none;
}
</style>
<script src="jquery-mobile/jquery-1.6.4.min.js" type="text/javascript"></script>
<script src="jquery-mobile/jquery.mobile-1.0.min.js" type="text/javascript"></script>
</head>

<body>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<div data-role="page" id="HYT">
  <div data-role="header">
    <h1><img src="image/img.png" width="985" height="97" alt="im" /></h1>
  </div>
  <div data-role="content">
    <form action="<?php echo $editFormAction; ?>" method="post" name="form2" id="form2">
      <div id="apDiv1">
        <p>TES<em><strong>T GROUP</strong></em><strong></strong></p>
        <ul>
          <li>BLOOD TESTING =N2500</li>
          <li>URINE TESTINE =3500</li>
          <li>SHIT TESTING =4500</li>
        </ul>
      </div>
      <table align="center" cellpadding="5">
        <tr valign="baseline" bgcolor="#999999">
          <td colspan="4" align="center" nowrap="nowrap"><strong><em>LABORATORY TESTING ROOM</em></strong></td>
        </tr>
        <tr valign="baseline">
          <td align="right" nowrap="nowrap" bgcolor="#999999"><span class="jh">patient_name</span>:</td>
          <td nowrap="nowrap" align="right"><input type="text" name="test_name" placeholder="THE SAME NAME ON YOUR CARD" value="" size="32" required="required" /></td>
          <td align="right" nowrap="nowrap" bgcolor="#999999">Price:</td>
          <td><input type="text" name="price" placeholder="LOOK UP FOR THE PRICE" value="" required="required" size="32" /></td>
        </tr>
        <tr valign="baseline">
          <td align="right" nowrap="nowrap" bgcolor="#999999">Test_group:</td>
          <td nowrap="nowrap" align="right"><input type="text" name="test_group" value="" placeholder="TEST GROUP?" size="32" required="required" /></td>
          <td align="right" nowrap="nowrap" bgcolor="#999999">Unit:</td>
          <td><input type="text" name="unit" placeholder="LOOK UP FOR THE UNIT" value="" size="32" required="required" /></td>
        </tr>
        <tr valign="baseline">
          <td align="right" nowrap="nowrap" bgcolor="#999999">Test_sub_group:</td>
          <td nowrap="nowrap" align="right"><input type="text" name="test_sub_group" placeholder="TEST TO UNDERGO?" value="" required="required" size="32" /></td>
          <td align="right" nowrap="nowrap" bgcolor="#999999">Resultday:</td>
          <td><input name="resultday" type="text" placeholder="PLEASE AWAIT LAB RESPONSE" value="PLESASE AWAIT NURSE REPORT" size="32" readonly="readonly" /></td>
        </tr>
        <tr valign="baseline" bgcolor="#999999">
          <td align="right" nowrap="nowrap">&nbsp;</td>
          <td align="right" nowrap="nowrap"><input type="submit" value="add test" /></td>
          <td align="right" nowrap="nowrap"><a href="index.php">homepage</a></td>
          <td><input name="Reset" type="reset" value="clear test" /></td>
        </tr>
      </table>
      <div id="apDiv2">
        <p><strong><em>TESTING UNIT.</em></strong></p>
        <ul>
          <li>BLOOD TESTING- UNIT 1</li>
          <li>URINE TESTINE - UNIT 2</li>
          <li>SHIT TESTING -- UNIT 3</li>
        </ul>
      </div>
<input type="hidden" name="MM_insert" value="form2" />
    </form>
  </div>
  <div data-role="footer">
    <h4>COPYRIGHT YUSIEFSON 2020<br />
    all right reserved. </h4>
  </div>
</div>
<p>&nbsp;</p>
<p>&nbsp;</p>
</body>
</html>
<?php
mysql_free_result($Recordset1);
?>
