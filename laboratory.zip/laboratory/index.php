<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>MediStop Laboratory services</title>
<link href="jquery-mobile/jquery.mobile-1.0.min.css" rel="stylesheet" type="text/css" />
<style type="text/css">
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
}
a:active {
	text-decoration: none;
}
LO {
	text-align: left;
}
body,td,th {
	font-family: "Comic Sans MS", cursive;
	text-align: center;
}
#apDiv1 {
	position: absolute;
	width: 507px;
	height: 60px;
	z-index: 1;
	color: #669;
	background-color: #999999;
	overflow: visible;
	left: 371px;
	top: 914px;
	background-image: url(image/LabImage/blood2.jpg);
}
</style>
<script src="jquery-mobile/jquery-1.6.4.min.js" type="text/javascript"></script>
<script src="jquery-mobile/jquery.mobile-1.0.min.js" type="text/javascript"></script>
</head>

<body>
<div data-role="page" id="ONE">
  <div data-role="header">
    <h1><img src="image/img.png" width="1093" height="114" alt="im" /></h1>
  </div>
  <div data-role="content" id="NEWT"><b><caption>YOU ARE WELCOME TO; MEDISTOP LABORATORY SERVICES.!</caption></b>
    <table width="711" height="405" border="0" cellpadding="20" cellspacing="15">
      <tr>
        <td width="353" height="216"><img src="image/LabImage/lab5.jpg" width="368" height="175" alt="l" /></td>
        <td width="352"><img src="image/LabImage/lab2.jpg" width="345" height="175" alt="ki" /></td>
        <td width="352"><img src="image/LabImage/blood2.jpg" width="351" height="175" /></td>
      </tr>
      <tr>
        <td height="169" bgcolor="#CCCCCC"><p>URINE SYRINGE TESTING:</p>
          <h6>comprise of all form of laboratory testing, from vacuum tube to conical, our expert are proffesional, give it a try now</h6>
          <p></p>
        <p>&nbsp;</p></td>
        <td bgcolor="#CCCCCC"><p>SHITTING TESTING: </p>
          <h6>comprise of all form of laboratory testing, from vacuum tube to conical, our expert are proffesional, give it a try now</h6>
        <p>&nbsp;</p></td>
        <td bgcolor="#CCCCCC"><p>BLOOD SAMPLE TESTING:</p>
          <h6>comprise of all form of laboratory testing, from vacuum tube to conical, our expert are proffesional, give it a try now</h6>
          <p></p>
        <p>&nbsp;</p></td>
      </tr>
    </table>
    <p>DESIGN AND IMPLEMENTATION OF LABORATORY SERVICE (CASE STUDY OF MEDISTOP LABORATORY SERVICE SOKOTO)</p>
    <p>PRESENTED BY:</p>
    <p>ABDULRASHID MUAZU</p>
    <p>PGD/IT/2018/065<BR /> 
      <center>
    </p>
    <fieldset>
      <legend></legend>
      <center>
        <p>&nbsp;</p>
        <form id="form1" name="form1" method="post" action="">
        SUBMITTED TO SCHOOL OF POST GRADUATE STUDY AGP T/MAFARA.
        </form>
        <center><div id="apDiv1">
        <p><a href="regnew.php">CLICK TO GET YOUR MEDICAL CARD</a></p></div></center>
        
       
    </center>
    <p>&nbsp;</br></fieldset>
    <p>
</div>
  <div data-role="footer">
    <h4>COPYRIGHT YUSIEFSON 2020<BR />all right reserved.  </h4>
  </div>
</div>
<p>
<p>
</body>
</html>