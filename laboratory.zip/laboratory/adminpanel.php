<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>MediStop Laboratory services</title>
<link href="jquery-mobile/jquery.mobile-1.0.min.css" rel="stylesheet" type="text/css" />
<style type="text/css">
a:link {
	text-decoration: none;
	color: #CCC;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
}
a:active {
	text-decoration: none;
}
.j {
	color: #63F;
}
</style>
<script src="jquery-mobile/jquery-1.6.4.min.js" type="text/javascript"></script>
<script src="jquery-mobile/jquery.mobile-1.0.min.js" type="text/javascript"></script>
</head>

<body>
<div data-role="page" id="ONE">
  <div data-role="header">
    <h1><img src="image/img.png" width="985" height="114" alt="im" /></h1>
  </div>
  <div data-role="content">
    <table width="353" border="1" cellpadding="4" cellspacing="4" summary="as the says "health="health" is="is" essential="essential"" your well="well" being="being" our="our" priority.!="priority.!"

a="a" system="system" with="with" features="features" that="that" support="support" modern="modern" laboratory="laboratory"'s operations.="operations." it="it" software="software" records,="records," manages="manages" and="and" stores="stores" data="data" for="for" clinical="clinical" laboratories....="laboratories...."">
      <caption>
        <em><strong>Medistop Laboratory Service Calender</strong></em><br />
      </caption>
      <tr>
        <th width="93" scope="col">DAYS</th>
        <th width="122" scope="col">HOURS</th>
      </tr>
      <tr>
        <th scope="row">SAT - SUN</th>
        <td>10:00 AM - 6:00PM</td>
        <td width="55"><img src="image/50_64x64.png" width="55" height="29" alt="K" /></td>
      </tr>
      <tr>
        <th scope="row">MON - FRI</th>
        <td>8:00AM - 10:00PM</td>
        <td><img src="image/50_64x64.png" width="55" height="29" alt="K" /></td>
      </tr>
    </table>
    
        
    <p>!!!YOU ARE WELLCOME,TO ADMINPANEL PAGE!!!!!    </p>
    <table width="940" border="0" align="center" cellpadding="5" cellspacing="20">
      <caption>
        CHECK AND MODIFY LAB STORE RECORD
      </caption>
      <tr>
        <th width="293" bgcolor="#3399CC" scope="col"><a href="patientad.php"><img src="image/about04.jpg" width="174" height="111" alt="N" /></a><br />
        <a href="patientad.php">PATIENT RECORDS</a></th>
        <th width="335" bgcolor="#00CC99" scope="col"><a href="doctorad.php"><img src="image/Picture2.png" width="182" height="111" alt="N" /></a><br />
        DOCTOR RECORD</th>
        <th width="202" bgcolor="#00CC99" scope="col"><a href="testresult.php"><img src="image/gallery/04.jpg" width="169" height="111" alt="JU" /></a><br />
        OTHER TEST RECORDS</th>
      </tr>
      <tr>
        <th bgcolor="#33CCFF" scope="col"><a href="nurse.php"><img src="image/about02.jpg" width="169" height="111" alt="M" /><br /> 
          </a><span class="j">NURSE RECORDS</span></th>
        <th bgcolor="#33FFFF" scope="col"><a href="searchfaci.php"><img src="image/gallery/15.jpg" width="169" height="111" alt="M" /></a><br />
        LAB FACILITY</th>
        <th bgcolor="#33FFFF" scope="col"><img src="image/gallery/02.jpg" width="169" height="111" alt="K" /><br />
        DRUGS &amp; MEDICINE</th>
      </tr>
    </table>
    <p>    
    <p>
</div>
  <div data-role="footer">
    <h4>&copy; COPYRIGHT &reg;YUSIEFSON 2020&#8482;<BR />all right reserved.  </h4>
  </div>
</div>
<p>
</body>
</html>