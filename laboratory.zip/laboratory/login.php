<?php require_once('Connections/laboratory.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}
?>
<?php
// *** Validate request to login to this site.
if (!isset($_SESSION)) {
  session_start();
}

$loginFormAction = $_SERVER['PHP_SELF'];
if (isset($_GET['accesscheck'])) {
  $_SESSION['PrevUrl'] = $_GET['accesscheck'];
}

if (isset($_POST['patience_id'])) {
  $loginUsername=$_POST['patience_id'];
  $password=$_POST['genotype'];
  $MM_fldUserAuthorization = "";
  $MM_redirectLoginSuccess = "LoginSucces.php";
  $MM_redirectLoginFailed = "LoginFailed.php";
  $MM_redirecttoReferrer = false;
  mysql_select_db($database_laboratory, $laboratory);
  
  $LoginRS__query=sprintf("SELECT patience_id, genotype FROM patients WHERE patience_id=%s AND genotype=%s",
    GetSQLValueString($loginUsername, "int"), GetSQLValueString($password, "text")); 
   
  $LoginRS = mysql_query($LoginRS__query, $laboratory) or die(mysql_error());
  $loginFoundUser = mysql_num_rows($LoginRS);
  if ($loginFoundUser) {
     $loginStrGroup = "";
    
	if (PHP_VERSION >= 5.1) {session_regenerate_id(true);} else {session_regenerate_id();}
    //declare two session variables and assign them
    $_SESSION['MM_Username'] = $loginUsername;
    $_SESSION['MM_UserGroup'] = $loginStrGroup;	      

    if (isset($_SESSION['PrevUrl']) && false) {
      $MM_redirectLoginSuccess = $_SESSION['PrevUrl'];	
    }
    header("Location: " . $MM_redirectLoginSuccess );
  }
  else {
    header("Location: ". $MM_redirectLoginFailed );
  }
}
?>
<?php require_once('Connections/laboratory.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_laboratory, $laboratory);
$query_Recordset1 = "SELECT patience_id, genotype FROM patients";
$Recordset1 = mysql_query($query_Recordset1, $laboratory) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
?>
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}
?>
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_laboratory, $laboratory);
$query_Recordset1 = "SELECT * FROM patients";
$Recordset1 = mysql_query($query_Recordset1, $laboratory) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>MediStop Laboratory services</title>
<link href="jquery-mobile/jquery.mobile-1.0.min.css" rel="stylesheet" type="text/css" />
<style type="text/css">
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: underline;
}
a:active {
	text-decoration: none;
}
#ONE div #form1 {
	text-align: center;
	font-weight: bold;
	font-style: italic;
}
</style>
<script src="jquery-mobile/jquery-1.6.4.min.js" type="text/javascript"></script>
<script src="jquery-mobile/jquery.mobile-1.0.min.js" type="text/javascript"></script>
</head>

<body>
<div data-role="page" id="ONE">
  <div data-role="header">
    <h6><img src="image/img.png" width="985" height="114" alt="im" /><a href="indexnew.php">BACKTO HOME</a></h6>
  </div>
  <div data-role="content">
    <table bgcolor="#663333" bordercolor="#33CC66" width="353" border="1" cellpadding="4" cellspacing="4">

      <caption>GENERAL NOTICE
        <em><strong> <marquee> Doctor. ABDULRASHID MUAZU JANGEBE and Nurse. AISHA NABERA NAGUDU and Nurse. JOY KURE ZANGO are on shifting today.</marquee>
        
        </strong></em>
      </caption>
    </table>
    <table width="200" border="1" cellspacing="0" cellpadding="0">
      <tr>
        <th scope="col"><table width="353" border="1" cellpadding="4" cellspacing="4" summary="as the says "health="health" is="is" essential="essential"" your well="well" being="being" our="our" priority.!="priority.!"

a="a" system="system" with="with" features="features" that="that" support="support" modern="modern" laboratory="laboratory"'s operations.="operations." it="it" software="software" records,="records," manages="manages" and="and" stores="stores" data="data" for="for" clinical="clinical" laboratories....="laboratories...."">
          <caption>
            <em><strong> Medistop Laboratory Service Calender</strong></em><br />
            </caption>
          <tr>
            <th width="93" scope="col">DAYS</th>
            <th width="122" scope="col">HOURS</th>
          </tr>
          <tr>
            <th scope="row">SAT - SUN</th>
            <td>10:00 AM - 6:00PM</td>
            <td width="55"><img src="image/50_64x64.png" width="55" height="29" alt="K" /></td>
          </tr>
          <tr>
            <th scope="row">MON - FRI</th>
            <td>8:00AM - 10:00PM</td>
            <td><img src="image/50_64x64.png" width="55" height="29" alt="K" /></td>
          </tr>
        </table></th>
      </tr>
    </table>
   <P> <form id="form1" name="form1" method="post" action="">
    FILL IN YOUR LOGIN DETAILS TO HAVE FULL MEDICAL ACCESS!
    </form>
    <form ACTION="<?php echo $loginFormAction; ?>" method="POST" name="form2" id="form2">
     <align>
     <div align="justify"></div>
     <table width="507" align="center" cellpadding="5">
        <tr valign="baseline" bgcolor="#FFCC99">
          <td height="117" colspan="4" align="right" nowrap="nowrap"><CENTER><img src="image/LabImage/pad1.jpg" name="QW" width="496" height="101" id="QW" /></CENTER></td>
        </tr>
        <tr valign="baseline">
          <td width="85" align="right" nowrap="nowrap" bgcolor="#FFCC99">Patience_id:</td>
          <td colspan="2" align="right" nowrap="nowrap" bgcolor="#FFCC99"><input type="text" name="patience_id" value="" size="32" /></td>
          <td width="192" rowspan="2"><img src="image/1_64x64.png" width="120" height="64" alt="fd" /></td>
        </tr>
        <tr valign="baseline">
          <td align="right" nowrap="nowrap" bgcolor="#FFCC99">Genotype:</td>
          <td colspan="2" align="right" nowrap="nowrap" bgcolor="#FFCC99"><input type="password" name="genotype" value="" size="32" /></td>
        </tr>
        <tr valign="baseline">
          <td bgcolor="#FFCC99"><input type="submit" value="LOG ME IN" />                    
          <td width="85" bgcolor="#FFCC99"><input name="Reset" type="reset" value="CLEAR" />                    
         <td width="85" height="37" bgcolor="#FFCC99"><a>
      </table><CENTER><BR /> 
      <a href="regnew.php"><CENTER>NEW PATIENTS? REGISTER HERE TO SIGN UP</CENTER></a>
    </form>
    <p>
</div>
  <div data-role="footer">
    <h4>&copy; COPYRIGHT &reg;YUSIEFSON 2020&#8482;<br />
    all right reserved. </h4>
  </div>
</div>
</body>
</html>
<?php
mysql_free_result($Recordset1);
?>
