<?php require_once('Connections/laboratory.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO `admin` (admin_log, adm_pwd) VALUES (%s, %s)",
                       GetSQLValueString($_POST['admin_log'], "text"),
                       GetSQLValueString($_POST['adm_pwd'], "int"));

  mysql_select_db($database_laboratory, $laboratory);
  $Result1 = mysql_query($insertSQL, $laboratory) or die(mysql_error());

  $insertGoTo = "adminpanel.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}

mysql_select_db($database_laboratory, $laboratory);
$query_Recordset1 = "SELECT * FROM `admin`";
$Recordset1 = mysql_query($query_Recordset1, $laboratory) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>MediStop Laboratory services</title>
<link href="jquery-mobile/jquery.mobile-1.0.min.css" rel="stylesheet" type="text/css" />
<style type="text/css">
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
}
a:active {
	text-decoration: none;
}
</style>
<script src="jquery-mobile/jquery-1.6.4.min.js" type="text/javascript"></script>
<script src="jquery-mobile/jquery.mobile-1.0.min.js" type="text/javascript"></script>
</head>

<body>
<div data-role="page" id="ONE">
  <div data-role="header">
    <h1><img src="image/img.png" width="985" height="114" alt="im" /></h1>
  </div>
  <div data-role="content">
    <table width="353" border="1" cellpadding="4" cellspacing="4" summary="as the says "health="health" is="is" essential="essential"" your well="well" being="being" our="our" priority.!="priority.!"

a="a" system="system" with="with" features="features" that="that" support="support" modern="modern" laboratory="laboratory"'s operations.="operations." it="it" software="software" records,="records," manages="manages" and="and" stores="stores" data="data" for="for" clinical="clinical" laboratories....="laboratories...."">
      <caption>
        <em><strong><br />
        Medistop Laboratory Service Calender</strong></em><br />
      </caption>
      <tr>
        <th width="93" scope="col">DAYS</th>
        <th width="122" scope="col">HOURS</th>
      </tr>
      <tr>
        <th scope="row">SAT - SUN</th>
        <td>10:00 AM - 6:00PM</td>
        <td width="55"><img src="image/50_64x64.png" width="55" height="29" alt="K" /></td>
      </tr>
      <tr>
        <th scope="row">MON - FRI</th>
        <td>8:00AM - 10:00PM</td>
        <td><img src="image/50_64x64.png" width="55" height="29" alt="K" /></td>
      </tr>
    </table>
    
    <form method="post" name="form3" id="form3">
    </form>
    <form action="<?php echo $editFormAction; ?>" method="post" name="form1" id="form1">
      <table align="center">
        <tr valign="baseline" bgcolor="#339999">
          <td height="159" colspan="2" align="center" valign="middle" nowrap="nowrap"><p><img src="image/LabImage/pad2.png" width="128" height="99" /></p>
          <p>admin only!</p></td>
        </tr>
        <tr valign="baseline">
          <td align="right" nowrap="nowrap" bgcolor="#339999">Admin_log:</td>
          <td><input type="text" name="admin_log" value="" size="32" /></td>
        </tr>
        <tr valign="baseline">
          <td align="right" nowrap="nowrap" bgcolor="#339999">Adm_pwd:</td>
          <td><input type="password" name="adm_pwd" value="" size="32" /></td>
        </tr>
        <tr valign="baseline" bgcolor="#339999">
          <td align="right" nowrap="nowrap">&nbsp;</td>
          <td><input name="Submit" type="submit" value="Get Access" />
          <input name="Submit2" type="reset" value="CLEAR" /></td>
        </tr>
      </table>
      <input type="hidden" name="MM_insert" value="form1" />
    </form>
    <p>&nbsp;</p>
    <p>
</div>
  <div data-role="footer">
    <h4>COPYRIGHT YUSIEFSON 2020<BR />all right reserved.  </h4>
  </div>
</div>
</body>
</html>
<?php
mysql_free_result($Recordset1);

mysql_free_result($Recordset1);
?>
