<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled facebook</title>
<script src="../../SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<script src="../../SpryAssets/SpryValidationPassword.js" type="text/javascript"></script>
<link href="../../SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<link href="../../SpryAssets/SpryValidationPassword.css" rel="stylesheet" type="text/css" />
</head>

<body bgcolor="green">
<marquee direction="right"><img src="../../Ukashatu-1.jpg" width="300" height="300" alt="ukshattu" /></marquee>
<marquee direction="right"><h1><font color="blue">UKASHATU IBRAHIM TALATA MAFARA</marquee></h1></font>
<marquee direction="left"><h1><font color="yellow">ABDU GUSAU POLYTECHNIC TALATA MAFARA ZAMFARA STATE</marquee></h1></font>
<p>
<font color="dark green">please fill the following form carefully</font>
<fieldset>
  <legend>Last Name:</legend>
  <form id="form1" name="form1" method="post" action="">
    <span id="sprytextfield1">
      <label for="last"></label>
      <input type="text" name="last" id="last" />
      <br />
      <br />
      <span class="textfieldRequiredMsg">A value is required.</span></span>
    <p>First Name: </p>
    <p><span id="sprytextfield2">
      <label for="fir"></label>
      <input type="text" name="fir" id="fir" />
      <span class="textfieldRequiredMsg">A value is required.</span></span></p>
    <p>Middle Name:</p>
    <p> <span id="sprytextfield3">
      <label for="midd"></label>
      <input type="text" name="midd" id="midd" />
      <span class="textfieldRequiredMsg">A value is required.</span></span></p>
    <p>Password: </p>
    <p><span id="sprypassword1">
      <label for="p"></label>
      <input type="password" name="p" id="p" />
      <span class="passwordRequiredMsg">A value is required.</span></span></p>
    <p>Sex
      <label for="s"></label>
      <select name="s" id="s">
      </select>
    </p>
    <p>Local Gov't Area
      <label for="l"></label>
      <select name="l" id="l">
      </select>
    </p>
    <p>State of Origin
      <label for="s"></label>
      <select name="s2" id="s">
      </select>
    </p>
    <p>Nationality
      <label for="n"></label>
      <select name="n" id="n">
      </select>
    </p>
    <p>NOTIE!NOTICE!!NOTICE!!!</p>
    <p><font color="red">YOU DONOT SUBMIT UNTIL YOU VERIFY YOUR PASSWORD</font></p>
    <p>
      <input type="submit" name="login" id="login" value="Submit" />
    </p>
  </form>
</fieldset>

</script>
</body>
</html>