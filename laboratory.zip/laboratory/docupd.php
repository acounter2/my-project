<?php require_once('Connections/laboratory.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form1")) {
  $updateSQL = sprintf("UPDATE doctor SET dtr_name=%s, dtr_specific=%s, dtr_level=%s, dtr_last_opr=%s, dctr_age=%s, dctr_salary=%s WHERE dtr_id=%s",
                       GetSQLValueString($_POST['dtr_name'], "text"),
                       GetSQLValueString($_POST['dtr_specific'], "text"),
                       GetSQLValueString($_POST['dtr_level'], "text"),
                       GetSQLValueString($_POST['dtr_last_opr'], "text"),
                       GetSQLValueString($_POST['dctr_age'], "int"),
                       GetSQLValueString($_POST['dctr_salary'], "int"),
                       GetSQLValueString($_POST['dtr_id'], "int"));

  mysql_select_db($database_laboratory, $laboratory);
  $Result1 = mysql_query($updateSQL, $laboratory) or die(mysql_error());

  $updateGoTo = "doctorad.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $updateGoTo .= (strpos($updateGoTo, '?')) ? "&" : "?";
    $updateGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $updateGoTo));
}

$colname_Recordset1 = "-1";
if (isset($_GET['dtr_id'])) {
  $colname_Recordset1 = $_GET['dtr_id'];
}
mysql_select_db($database_laboratory, $laboratory);
$query_Recordset1 = sprintf("SELECT * FROM doctor WHERE dtr_id = %s", GetSQLValueString($colname_Recordset1, "int"));
$Recordset1 = mysql_query($query_Recordset1, $laboratory) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<form action="<?php echo $editFormAction; ?>" method="post" name="form1" id="form1">
  <table align="center">
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Dtr_id:</td>
      <td><?php echo $row_Recordset1['dtr_id']; ?></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Dtr_name:</td>
      <td><input type="text" name="dtr_name" value="<?php echo htmlentities($row_Recordset1['dtr_name'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Dtr_specific:</td>
      <td><input type="text" name="dtr_specific" value="<?php echo htmlentities($row_Recordset1['dtr_specific'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Dtr_level:</td>
      <td><input type="text" name="dtr_level" value="<?php echo htmlentities($row_Recordset1['dtr_level'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Dtr_last_opr:</td>
      <td><input type="text" name="dtr_last_opr" value="<?php echo htmlentities($row_Recordset1['dtr_last_opr'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Dctr_age:</td>
      <td><input type="text" name="dctr_age" value="<?php echo htmlentities($row_Recordset1['dctr_age'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Dctr_salary:</td>
      <td><input type="text" name="dctr_salary" value="<?php echo htmlentities($row_Recordset1['dctr_salary'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">&nbsp;</td>
      <td><input type="submit" value="Update record" /></td>
    </tr>
  </table>
  <input type="hidden" name="MM_update" value="form1" />
  <input type="hidden" name="dtr_id" value="<?php echo $row_Recordset1['dtr_id']; ?>" />
</form>
<p>&nbsp;</p>
</body>
</html>
<?php
mysql_free_result($Recordset1);
?>
