<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="jquery-mobile/jquery.mobile.theme-1.0.min.css" rel="stylesheet" type="text/css" />
<link href="jquery-mobile/jquery.mobile.structure-1.0.min.css" rel="stylesheet" type="text/css" />
<script src="jquery-mobile/jquery-1.6.4.min.js" type="text/javascript"></script>
<script src="jquery-mobile/jquery.mobile-1.0.min.js" type="text/javascript"></script>
</head>

<body>
<div data-role="page" id="Ipage">
  <div data-role="header">
    <h1>LAB REPORT</h1>
  </div>
  <div data-role="content">
    <form id="searchlabtest" name="searchlabtest" method="post" action="labfound.php">
      TYPE YOUR NAME
      <label for="search"></label>
      <input type="text" name="search" id="search" />
      <input type="submit" name="btn" id="btn" value="search" />
    </form>
  </div>
  <div data-role="footer">
    <h4>COPYRIGHT YUSIEFSON 2020<br />
    all right reserved. </h4>
  </div>
</div>
</body>
</html>