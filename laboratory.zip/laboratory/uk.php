<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled facebook</title>
<style type="text/css">
.B {
	color: #F00;
}
</style>
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<link href="SpryAssets/SpryValidationPassword.css" rel="stylesheet" type="text/css" />
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<script src="SpryAssets/SpryValidationPassword.js" type="text/javascript"></script>
</head>

<body class="B" bgcolor="#00CC00">
<marquee direction="right"><H2>UKASHATU IBRAHIM TALATA MAFARA</marquee><h2>
<marquee direction="left"><h2>ABDU GUSAU POLYTECHNIC TALATA MAFARA ZAMFARA STATE</marquee></h2>
<p>PLEASE FILL THE FOLLOWING FORM
</p>
<fieldset>
  <legend></legend>
  <p>Last Name: </p>
  <form id="form1" name="form1" method="post" action="">
<span id="sprytextfield1">
      <label for="last"></label>
      <input type="text" name="last" id="last" />
      <span class="textfieldRequiredMsg">A value is required.</span></span>
    <p>First Name:</p>
    <p> <span id="sprytextfield2">
      <label for="first"></label>
      <input type="text" name="first" id="first" />
      <span class="textfieldRequiredMsg">A value is required.</span></span></p>
    <p>Password:</p>
    <p> <span id="sprypassword1">
      <label for="pass"></label>
      <input type="password" name="pass" id="pass" />
      <span class="passwordRequiredMsg">A value is required.</span></span></p>
    <p>Sex:
      <label for="sex"></label>
      <select name="sex" id="sex">
      </select>
    </p>
    <p>Marital Status: 
      <label for="mari"></label>
      <select name="mari" id="mari">
      </select>
    </p>
    <p>Local Gov't Area: 
      <label for="l"></label>
      <select name="l" id="l">
      </select>
    </p>
    <p>State of Origin: 
      <label for="select"></label>
      <select name="select" id="select">
      </select>
    </p>
    <p>Nationality: 
      <label for="n"></label>
      <select name="n" id="n">
      </select>
    </p>
    <p>Is an advise to All facebook Users dont accept any friend request, untill you know that person because he would make a major problem to you facebook users</p>
    <p>&nbsp;</p>
<p>NOTICE!NOTICE!!NOTICE!!!</p>
<p>Please donot submmit untill you verify your password is correct</p>
    <p>
   <marquee direction="right">
   <p><img src="erg stamp.png" width="415" height="209" alt="A" /></marquee></p>
    <marquee direction="left">
    <p>
</marquee>> </p>
   <form id="form1" name="form1" method="post" action="">
     <input type="submit" name="s" id="s" value="Submit" />
   </form>
   <p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<script type="text/javascript">
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2");
var sprypassword1 = new Spry.Widget.ValidationPassword("sprypassword1");
</script>
</body>
</html>