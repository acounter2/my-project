<?php require_once('Connections/laboratory.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_Recordset1 = "-1";
if (isset($_POST['search'])) {
  $colname_Recordset1 = $_POST['search'];
}
mysql_select_db($database_laboratory, $laboratory);
$query_Recordset1 = sprintf("SELECT * FROM lab_test WHERE test_name = %s", GetSQLValueString($colname_Recordset1, "text"));
$Recordset1 = mysql_query($query_Recordset1, $laboratory) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="jquery-mobile/jquery.mobile.theme-1.0.min.css" rel="stylesheet" type="text/css" />
<link href="jquery-mobile/jquery.mobile.structure-1.0.min.css" rel="stylesheet" type="text/css" />
<style type="text/css">
#Kpage div {
	text-align: center;
}
#Kpage div table tr th {
	color: #333;
	font-size: 12px;
}
#Kpage div table tr td p {
	font-weight: bold;
	font-style: italic;
	font-size: 12px;
}
#Kpage div table {
	font-style: italic;
	font-weight: normal;
	text-align: center;
}
#Kpage {
	font-weight: bold;
}
#Kpage div table tr th p {
	font-size: 16px;
}
</style>
<script src="jquery-mobile/jquery-1.6.4.min.js" type="text/javascript"></script>
<script src="jquery-mobile/jquery.mobile-1.0.min.js" type="text/javascript"></script>
</head>

<body>
<div data-role="page" id="Kpage">
  <div data-role="header">
    <h1>PRINT TEST RESULT</h1>
  </div>
  <div data-role="content">
    <center><table class="row print-container" width="400" border="1" cellspacing="0" cellpadding="0">
      <tr>
        <th width="130" height="75
        " valign="middle" scope="col">RC: 1762255
        <p>Medistop Laboratory Services</p></th>
        <th width="300" scope="col"><p><img src="image/img.png" width="391" height="90" /></p></th>
      </tr>
      <tr>
        <th height="44" align="left" valign="middle" scope="col">DATE: ......................</th>
        <th scope="col">MEDICAL REPORT CARD</th>
      </tr>
      <tr>
        <td id="Kpage">TEST ID</td>
        <td><?php echo $row_Recordset1['test_id']; ?></td>
      </tr>
      <tr>
        <td>TEST NAME</td>
        <td><?php echo $row_Recordset1['test_name']; ?></td>
      </tr>
      <tr>
        <td>TEST SUB</td>
        <td><?php echo $row_Recordset1['test_group']; ?></td>
      </tr>
      <tr>
        <td>TEST SUB GROUP</td>
        <td><?php echo $row_Recordset1['test_sub_group']; ?></td>
      </tr>
      <tr>
        <td>PRICE CHARGED</td>
        <td><?php echo $row_Recordset1['price']; ?></td>
      </tr>
      <tr>
        <td>UNIT</td>
        <td><?php echo $row_Recordset1['unit']; ?></td>
      </tr>
      <tr>
        <td align="left" valign="top"><p>Doctor Sign:</p>
        <p>..................................</p>
        <p>Abdulrasheed Muazu</p></td>
        <td><p>comment/report:...............................................................</p>
        <p>precaution:.....................................................................</p></td>
      </tr>
      <tr>
        <td align="left" valign="top">&nbsp;</td>
        <td><style>
	  @media print{
		  /* Hide every other element */
		  body * {
			  visibility:hidden;
		  }
		  /* then displaying print container element */
		  .print-container, .print-container *{
			  visibility:visible;
		  }
		  }
		  
	  
	  </style>
      <button onClick="window.print() ">print</button></td>
      </tr>
    </table>
    <form id="searchfaci" name="searchfaci" method="post" action="facility.php">
      <label for="search"></label>
    </form>
  </div>
  <div data-role="footer">
    <h4>COPYRIGHT YUSIEFSON 2020<br />
all right reserved. </h4>
  </div>
</div>
</body>
</html>
<?php
mysql_free_result($Recordset1);
?>
