<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_laboratory = "127.0.0.1";
$database_laboratory = "laboratory";
$username_laboratory = "root";
$password_laboratory = "";
$laboratory = mysql_pconnect($hostname_laboratory, $username_laboratory, $password_laboratory) or trigger_error(mysql_error(),E_USER_ERROR); 
?>