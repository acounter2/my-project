<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_uk = "localhost";
$database_uk = "evoting";
$username_uk = "evoting";
$password_uk = "12345";
$uk = mysql_pconnect($hostname_uk, $username_uk, $password_uk) or trigger_error(mysql_error(),E_USER_ERROR); 
?>