<?php require_once('Connections/laboratory.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form2")) {
  $insertSQL = sprintf("INSERT INTO patients (patience_name, patience_no, sex, age, reg_date, blood_group, genotype) VALUES (%s, %s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['patience_name'], "text"),
                       GetSQLValueString($_POST['patience_no'], "int"),
                       GetSQLValueString($_POST['sex'], "text"),
                       GetSQLValueString($_POST['age'], "int"),
                       GetSQLValueString($_POST['reg_date'], "int"),
                       GetSQLValueString($_POST['blood_group'], "text"),
                       GetSQLValueString($_POST['genotype'], "text"));

  mysql_select_db($database_laboratory, $laboratory);
  $Result1 = mysql_query($insertSQL, $laboratory) or die(mysql_error());

  $insertGoTo = "patrepsrh.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}

mysql_select_db($database_laboratory, $laboratory);
$query_Recordset1 = "SELECT * FROM patients";
$Recordset1 = mysql_query($query_Recordset1, $laboratory) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
#nm {
	font-family: "MS Serif", "New York", serif;
	color: #F00;
	text-decoration: blink;
	background-attachment: scroll;
	background-image: url(image/avator.png);
	background-repeat: no-repeat;
}
#form2 table tr #nm {
	font-weight: bold;
}
#form2 table tr td {
	font-weight: bold;
	color: #F00;
}
</style>
<link href="jquery-mobile/jquery.mobile.theme-1.0.min.css" rel="stylesheet" type="text/css" />
<link href="jquery-mobile/jquery.mobile.structure-1.0.min.css" rel="stylesheet" type="text/css" />
<style type="text/css">
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: underline;
}
a:active {
	text-decoration: none;
}
</style>
<script src="jquery-mobile/jquery-1.6.4.min.js" type="text/javascript"></script>
<script src="jquery-mobile/jquery.mobile-1.0.min.js" type="text/javascript"></script>
</head>

<body>
<p>&nbsp;</p>
<div data-role="page" id="pnj">
  <div data-role="header">
    <h1><img src="image/img.png" width="985" height="97" alt="im" /></h1>
  </div>
  <div data-role="content">
    <form action="<?php echo $editFormAction; ?>" method="post" name="form2" id="form2">
      <table align="center" cellpadding="10">
        <tr valign="baseline">
          <td nowrap="nowrap" align="right">&nbsp;</td>
          <td colspan="2" id="nm">All Information should be  carefully and clearly provided without any errors! </td>
          <td>&nbsp;</td>
        </tr>
        <tr valign="baseline">
          <td nowrap="nowrap" align="right">Patience_name:</td>
          <td><input type="text" name="patience_name" placeholder=" patient Call name" value="" size="32" /></td>
          <td>Age:</td>
          <td><input type="text" name="age" placeholder=" patient Date of birth" value="" size="32" /></td>
        </tr>
        <tr valign="baseline">
          <td nowrap="nowrap" align="right">Patience_no:</td>
          <td><input type="text" name="patience_no" placeholder=" patient GSM Number" value="" size="32" /></td>
          <td>Reg_date:</td>
          <td><input type="date" name="reg_date" placeholder=" patient registerd date" value="" size="32" /></td>
        </tr>
        <tr valign="baseline">
          <td nowrap="nowrap" align="right">Sex:</td>
          <td><input type="text" name="sex" placeholder=" patient gender status" value="" size="32" /></td>
          <td>Blood_group:</td>
          <td><input type="text" name="blood_group" placeholder=" patient blood family" value="" size="32" /></td>
        </tr>
        <tr valign="baseline">
          <td nowrap="nowrap" align="right">Genotype:</td>
          <td><input type="text" name="genotype" placeholder=" patient geno status" value="" size="32" /></td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr valign="baseline">
          <td nowrap="nowrap" align="right">&nbsp;</td>
          <td><input type="submit" value="Add Patient" /></td>
          <td>&nbsp;</td>
          <td><input name="Reset" type="reset" value="Clear Detail" /></td>
        </tr>
      </table>
      <p>&nbsp;</p>
      <p></br>
        EXISTING PATIENT? <a href="login.php">LOGIN HERE!</a></p>
<input type="hidden" name="MM_insert" value="form2" />
    </form>
  </div>
  <div data-role="footer">
    <h4>COPYRIGHT YUSIEFSON 2020<br />
    all right reserved. </h4>
  </div>
</div>
</body>
</html>
<?php
mysql_free_result($Recordset1);
?>
