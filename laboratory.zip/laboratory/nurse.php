<?php require_once('Connections/laboratory.php'); ?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "admin.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($_SERVER['QUERY_STRING']) && strlen($_SERVER['QUERY_STRING']) > 0) 
  $MM_referrer .= "?" . $_SERVER['QUERY_STRING'];
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_laboratory, $laboratory);
$query_Recordset1 = "SELECT * FROM nurse";
$Recordset1 = mysql_query($query_Recordset1, $laboratory) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>MediStop Laboratory services</title>
<link href="jquery-mobile/jquery.mobile-1.0.min.css" rel="stylesheet" type="text/css" />
<style type="text/css">
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
}
a:active {
	text-decoration: none;
}
</style>
<script src="jquery-mobile/jquery-1.6.4.min.js" type="text/javascript"></script>
<script src="jquery-mobile/jquery.mobile-1.0.min.js" type="text/javascript"></script>
</head>

<body>
<div data-role="page" id="ONE">
  <div data-role="header">
    <h1><img src="image/img.png" width="985" height="114" alt="im" /></h1>
  </div>
  <div data-role="content">
    <table width="353" border="1" cellpadding="4" cellspacing="4" summary="as the says "health="health" is="is" essential="essential"" your well="well" being="being" our="our" priority.!="priority.!"

a="a" system="system" with="with" features="features" that="that" support="support" modern="modern" laboratory="laboratory"'s operations.="operations." it="it" software="software" records,="records," manages="manages" and="and" stores="stores" data="data" for="for" clinical="clinical" laboratories....="laboratories...."">
      <caption>
        <em><strong>Medistop Laboratory Service Calender</strong></em><br />
      </caption>
      <tr>
        <th width="93" scope="col">DAYS</th>
        <th width="122" scope="col">HOURS</th>
      </tr>
      <tr>
        <th scope="row">SAT - SUN</th>
        <td>10:00 AM - 6:00PM</td>
        <td width="55"><img src="image/50_64x64.png" width="55" height="29" alt="K" /></td>
      </tr>
      <tr>
        <th scope="row">MON - FRI</th>
        <td>8:00AM - 10:00PM</td>
        <td><img src="image/50_64x64.png" width="55" height="29" alt="K" /></td>
      </tr>
    </table>
    
    <BR />
    <fieldset>
      <legend>
all nurses list here
<table width="1013" border="1" cellpadding="4" cellspacing="4">
  <tr>
    <td width="142">nrs_id</td>
    <td width="168">nrs_name</td>
    <td width="175">nurse_dprt</td>
    <td width="159">attached</td>
    <td width="143">record</td>
    <td width="60">Edit info</td>
    <td width="62">Add info</td>
  </tr>
  <?php do { ?>
    <tr>
      <td><?php echo $row_Recordset1['nrs_id']; ?></td>
      <td><?php echo $row_Recordset1['nrs_name']; ?></td>
      <td><?php echo $row_Recordset1['nurse_dprt']; ?></td>
      <td><?php echo $row_Recordset1['attached']; ?></td>
      <td><?php echo $row_Recordset1['record']; ?></td>
      <td><a href="nurseupd.php?nrs_id=<?php echo $row_Recordset1['nrs_id']; ?>"><img src="image/products_but.png" width="81" height="47" alt="m" /></a></td>
      <td><a href="delnur.php?nrs_id=<?php echo $row_Recordset1['nrs_id']; ?>"><img src="image/close.png" width="80" height="39" alt="m" /></a></td>
    </tr>
    <?php } while ($row_Recordset1 = mysql_fetch_assoc($Recordset1)); ?>
</table>
</legend>
      <p><a href="nursereg.php">add new nurse</a></p>
    </fieldset>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
<p>
<p>
</div>
  <div data-role="footer">
    <h4>COPYRIGHT YUSIEFSON 2020<BR />all right reserved.  </h4>
  </div>
</div>
<p>
<p>
<p>
<p>
</body>
</html>
<?php
mysql_free_result($Recordset1);
?>
