<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>human resources system</title>
<style type="text/css">
body {
	background-color: #999;
}
#J {
	color: #630;
}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: underline;
}
a:active {
	text-decoration: none;
}
.n {
	text-align: center;
}
#LO {
	color: #F00;
}
</style>
</head>


<body><CENTER>
<img src="HR.png" width="1200" height="183" /><thead align="center" valign="middle" bgcolor="#669999">
<a href="index.php">Visit our page</a>
</thead><thead align="center" valign="middle" bgcolor="#669999">
<span style="color: #999; font-family: 'Lucida Sans Unicode', 'Lucida Grande', sans-serif;">HOMEPAGE2</span>
</thead></CENTER><thead align="center" valign="middle" bgcolor="#669999">
<a href="ono.php">TRANSFER N TERMINATE
</thead>
</a>
<thead align="center" valign="middle" bgcolor="#669999">
<span style="color: #999; font-family: 'Lucida Sans Unicode', 'Lucida Grande', sans-serif;">HOM
</thead>
<a href="staff.php">STAFF PROMOTION</a></span><span style="color: #999; font-family: 'Lucida Sans Unicode', 'Lucida Grande', sans-serif;">PAGE6</span>
<a href="hiring.php">
</thead>
</CENTER>
</a>
<thead align="center" valign="middle" bgcolor="#669999">
<a href="hiring.php">HIRING AND RECRUITING
</thead>
</a>
<thead align="center" valign="middle" bgcolor="#669999">
<span style="color: #999; font-family: 'Lucida Sans Unicode', 'Lucida Grande', sans-serif;">Visit our page8</span>
</thead><span style="color: #999; font-family: 'Lucida Sans Unicode', 'Lucida Grande', sans-serif;">HOMEPAGE6</span>
</thead>
<a href="rota.php">
</CENTER>
</a>
<thead align="center" valign="middle" bgcolor="#669999">
<a href="rota.php">ROTA MANAGEMENT</a>
</thead><thead align="center" valign="middle" bgcolor="#669999">
<span style="color: #999; font-family: 'Lucida Sans Unicode', 'Lucida Grande', sans-serif;">V                     <a href="about.php">ABOUT US</a>iisit our page8</span><a href="staff.php"><span style="color: #999; font-family: 'Lucida Sans Unicode', 'Lucida Grande', sans-serif;">H</span></a>
<table width="1120" border="1">
  <tr>
    <th width="226" scope="col">&nbsp;</th>
    <th width="262" scope="col">Activities</th>
    <th width="312" style="color: #FFF" scope="col">Submit your CV and application letter with us and get the best job <a href="hiring.php">HERE</a></th>
  </tr>
  <tr>
    <td><span style="font-variant: normal; font-weight: lighter; line-height: normal; font-style: italic; font-size: 14px; font-family: monospace, fantasy, cursive, Terminal;"><img src="HRLOGO.png" alt="" width="225" height="216" /></span></td>
    <td align="left" valign="top"><ul>
      <li>Determine needs of the staff.</li>
      <li>Determine to use temporary staff or hire  employees to fill these needs.</li>
      <li>Determine Do's &amp; Don'ts.</li>
      <li>Recruit the best employees</li>
      <li>Train employees. Upgrade their learning  knowledge.</li>
      <li>Supervise the work.</li>
      <li>Evaluate the work.</li>
    </ul>
    Establish 'Discipline work  culture' in the organization.</td>
    <td align="left" valign="top"><ul>
      <li>Avoid Politics in office.</li>
      <li>Apply 'HR Software' for the ease of work in  the organization.</li>
      <li>Manage employee relations. If there are unions  perform collective bargaining.</li>
      <li>Prepare employee records and personal  policies.</li>
      <li>Manage employee payroll, benefits and  compensation.</li>
      <li>Ensure equal opportunities.</li>
      <li>Deal with discrimination.</li>
      <li>Deal with performance issues.</li>
      <li>Ensure that human resources practices  conform to various regulations.</li>
      <li><a href="https://en.wikipedia.org/wiki/Motivation" title="Motivation">Motivate</a>&nbsp;employees</li>
      <li>Mediate disputes</li>
      <li>Disseminate information in the organization  so as to benefit its growth.</li>
    </ul></td>
  </tr>
  <tr>
    <td><strong>COURSE TITLE</strong></td>
    <td><strong>MULTIMEDIA</strong></td>
    <td>&nbsp;</td>
  </tr>
</table>
<div align="center"><span style="font-variant: normal; font-weight: lighter; line-height: normal; font-style: italic; font-size: 14px; font-family: monospace, fantasy, cursive, Terminal;">A human resources management system ensures everyday human resources processes are manageable and easy to access. It merges human resources as a discipline and, in particular, its basic HR activities and processes with the information technology field, whereas the programming of data processing systems evolved into standardized routines and packages of  resource planning" enterprise resource planning</a> (ERP) software. On the whole, these ERP systems have their origin from software that integrates information from different applications into one universal database. The linkage of its financial and human resource modules through one database is the most important distinction to the individually and proprietarily developed predecessors, which makes this software application both rigid and flexible.</span></div>
<table width="348" align="center">
  <tr>
    <th colspan="2" bgcolor="#666666" scope="col"><img src="adminuser.png" width="239" height="128" /></th>
  </tr>
  <tr>
    <th colspan="2" bgcolor="#666633" id="J" scope="col">GROUP MEMBERS</th>
  </tr>
  <tr class="n">
    <td width="110" bgcolor="#00CC99"><strong>REGNO</strong></td>
    <td width="237" bgcolor="#00CC99"><strong>NAMES</strong></td>
  </tr>
  <tr>
    <td bgcolor="#00CC99">1807223021</td>
    <td bgcolor="#00CC99">ABUBAKAR MUHAMMAD</td>
  </tr>
  <tr>
    <td bgcolor="#00CC99">1807223022</td>
    <td bgcolor="#00CC99">AMINU ABUBAKAR</td>
  </tr>
  <tr>
    <td bgcolor="#00CC99">1807223023</td>
    <td bgcolor="#00CC99">&nbsp;</td>
  </tr>
  <tr>
    <td bgcolor="#00CC99">1807223024</td>
    <td bgcolor="#00CC99">AMINU ABDULAHI TAMBARI</td>
  </tr>
</table>

</body>
</html>