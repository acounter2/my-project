<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>human resources system</title>
<style type="text/css">
body {
	background-color: #999;
}
#J {
	color: #630;
}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: underline;
}
a:active {
	text-decoration: none;
}
</style>
</head>


<body><CENTER>
<img src="HR.png" width="1200" height="183" /><thead align="center" valign="middle" bgcolor="#669999">
<a href="index.php">Visit our page</a>
</thead><thead align="center" valign="middle" bgcolor="#669999">
<span style="color: #999; font-family: 'Lucida Sans Unicode', 'Lucida Grande', sans-serif;">HOMEPAGE2</span>
</thead></CENTER><thead align="center" valign="middle" bgcolor="#669999">
<a href="ono.php">OFF AND ONBOARDING</a>
</thead><thead align="center" valign="middle" bgcolor="#669999">
<span style="color: #999; font-family: 'Lucida Sans Unicode', 'Lucida Grande', sans-serif;">HOMEPAGE4</span>
</thead></CENTER><thead align="center" valign="middle" bgcolor="#669999">
<a href="staff.php">STAFF
</thead>
</a>
<thead align="center" valign="middle" bgcolor="#669999">
<span style="color: #999; font-family: 'Lucida Sans Unicode', 'Lucida Grande', sans-serif;">HOMEPAGE6</span>
</thead></CENTER><thead align="center" valign="middle" bgcolor="#669999">
<a href="hiring.php">HIRING AND RECRUITING</a>
</thead><thead align="center" valign="middle" bgcolor="#669999">
<span style="color: #999; font-family: 'Lucida Sans Unicode', 'Lucida Grande', sans-serif;">Visit our page8</span>
</thead><span style="color: #999; font-family: 'Lucida Sans Unicode', 'Lucida Grande', sans-serif;">HOMEPAGE6</span>
<a href="rota.php">
</thead>
</CENTER>
</a>
<thead align="center" valign="middle" bgcolor="#669999">
<a href="rota.php">ROTA MANAGEMENT
</thead>
</a>
<thead align="center" valign="middle" bgcolor="#669999">
<span style="color: #999; font-family: 'Lucida Sans Unicode', 'Lucida Grande', sans-serif;">Visit our page8</span>
</thead>
<fieldset>
  <legend style="color: #3F3">SUBMIT YOUR CREDENTILAS WE SHALL CONTACT YOU FOR JOB OPPORTUNITY</legend>
  <form action="" method="post" enctype="multipart/form-data" name="form1" id="form1">
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <table width="534" height="135" border="1" align="center" cellpadding="10" cellspacing="5">
      <tr bgcolor="#00CC99">
        <th width="73" scope="col"><label for="CV2">Insert  your CV</label></th>
        <th width="218" scope="col"><input type="file" name="CV" id="CV" />      </th>
        <th width="63" rowspan="2" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <td bgcolor="#33FF33"><label for="LEETER"><strong>Application Letter</strong></label></td>
        <td><input type="file" name="LEETER" id="LEETER" /></td>
      </tr>
      <tr bgcolor="#33FF33">
        <td height="27">&nbsp;</td>
        <td><input type="submit" name="upl" id="upl" value="UPLOAD &amp; SUBMIT" /></td>
        <td>&nbsp;</td>
      </tr>
    </table>
    <p><a href="rota.php">CHECK OUR POLICY AND SEVICE</a></p>
    <p>Managers need to develop their&nbsp;<a href="https://en.wikipedia.org/wiki/Social_skills" title="Social skills">interpersonal skills</a>&nbsp;to be effective.  Organizations behavior focuses on how to improve factors that make  organizations more effective.</p>
</form>
</fieldset>
</body>
</html>