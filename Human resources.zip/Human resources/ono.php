<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>human resources system</title>
<style type="text/css">
body {
	background-color: #999;
}
#J {
	color: #630;
}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: underline;
}
a:active {
	text-decoration: none;
}
</style>
</head>


<body><CENTER>
<img src="HR.png" width="1200" height="183" /><thead align="center" valign="middle" bgcolor="#669999">
<a href="index.php">Visit our page
</thead>
</a>
<thead align="center" valign="middle" bgcolor="#669999">
<span style="color: #999; font-family: 'Lucida Sans Unicode', 'Lucida Grande', sans-serif;">HOMEPAGE2</span>
</thead></CENTER><thead align="center" valign="middle" bgcolor="#669999">
<a href="ono.php">TRANSFER N TERMINATE</a>
</thead>
<thead align="center" valign="middle" bgcolor="#669999">
<span style="color: #999; font-family: 'Lucida Sans Unicode', 'Lucida Grande', sans-serif;">HOMEPAGE4</span>
</thead>
<a href="staff.php">
</CENTER>
</a>
<thead align="center" valign="middle" bgcolor="#669999">
<a href="staff.php">STAFF PROMOTION</a>
</thead>
<thead align="center" valign="middle" bgcolor="#669999">
<span style="color: #999; font-family: 'Lucida Sans Unicode', 'Lucida Grande', sans-serif;">HOMEPAGE6</span>
</thead></CENTER><thead align="center" valign="middle" bgcolor="#669999">
<a href="hiring.php">HIRING AND RECRUITING
</thead>
</a>
<thead align="center" valign="middle" bgcolor="#669999">
<span style="color: #999; font-family: 'Lucida Sans Unicode', 'Lucida Grande', sans-serif;">Visit our page8</span>
</thead><span style="color: #999; font-family: 'Lucida Sans Unicode', 'Lucida Grande', sans-serif;">HOMEPAGE6</span>
</thead></CENTER><thead align="center" valign="middle" bgcolor="#669999">
<a href="rota.php">ROTA MANAGEMENT
</thead>
</a>
<thead align="center" valign="middle" bgcolor="#669999">
<p><span style="color: #999; font-family: 'Lucida Sans Unicode', 'Lucida Grande', sans-serif;">Visit our page8</span>
  </thead>
</p>
<table width="698" border="1" align="center" cellpadding="7" cellspacing="15">
  <tr bgcolor="#66CCCC">
    <th width="75" scope="col">STAFF ID</th>
    <th width="227" scope="col">FULL NAME</th>
    <th width="156" scope="col">ORGANISATION</th>
    <th width="99" scope="col">STATUS</th>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td>2532</td>
    <td>SHADE OLAOLUWA</td>
    <td>OLIVIER PEST LTD.</td>
    <td bgcolor="#FF0000">TERMINATED</td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td>25622</td>
    <td>PAUL DANIEL</td>
    <td>NESTLE NG</td>
    <td bgcolor="#00FF00">TRANSFERED</td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td>5522</td>
    <td>AMINA GARBA</td>
    <td>FISRTBANK PLC</td>
    <td bgcolor="#00FF00">TRANSFERED</td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td>2555</td>
    <td>AUDU BAKO KANO</td>
    <td>BUK KANO</td>
    <td bgcolor="#FF0000">TERMINATED</td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td>5444</td>
    <td>DAHIRU ABU </td>
    <td>AGP T/M</td>
    <td bgcolor="#FF0000">TERMINATED</td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td>22222</td>
    <td>SHEHU MUHAMMAD</td>
    <td>AGP T/M</td>
    <td bgcolor="#00FF00">TRANSFERED</td>
  </tr>
</table>
</body>
</html>