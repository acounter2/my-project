<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>human resources system</title>
<style type="text/css">
body {
	background-color: #999;
}
#J {
	color: #630;
}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: underline;
}
a:active {
	text-decoration: none;
}
body,td,th {
	font-family: serif, Roman, Modern;
	color: #3FC;
}
.j {
	font-style: italic;
	color: #9F0;
}
</style>
</head>


<body><CENTER>
<img src="HR.png" width="1200" height="170" /><thead align="center" valign="middle" bgcolor="#669999">
<a href="index.php">Visit our page</a><a href="hiring.php">
</thead>
</a>
<thead align="center" valign="middle" bgcolor="#669999">
<span style="color: #999; font-family: 'Lucida Sans Unicode', 'Lucida Grande', sans-serif;">HOMEPAGE2</span>
</thead></CENTER><thead align="center" valign="middle" bgcolor="#669999">
<a href="ono.php">TRANSFER N TERMINATE</a>
</thead>
<thead align="center" valign="middle" bgcolor="#669999">
<span style="color: #999; font-family: 'Lucida Sans Unicode', 'Lucida Grande', sans-serif;">HOMEPAGE4</span>
</thead></CENTER><thead align="center" valign="middle" bgcolor="#669999">
<a href="staff.php">STAFF PROMOTION</a>
</thead>
<thead align="center" valign="middle" bgcolor="#669999">
<span style="color: #999; font-family: 'Lucida Sans Unicode', 'Lucida Grande', sans-serif;">HOMEPAGE6</span>
</thead></CENTER><thead align="center" valign="middle" bgcolor="#669999">
<a href="hiring.php">HIRING AND RECRUITING</a>
</thead><thead align="center" valign="middle" bgcolor="#669999">
<span style="color: #999; font-family: 'Lucida Sans Unicode', 'Lucida Grande', sans-serif;">Visit ou       </span>
<thead align="center" valign="middle" bgcolor="#669999"><a href="rota.php">ROTA MANAGEMENT</a>
</thead><thead align="center" valign="middle" bgcolor="#669999">
 <span style="color: #999; font-family: 'Lucida Sans Unicode', 'Lucida Grande', sans-serif;">V                <a href="about.php">ABOUT US</a>isit our page8</span>
</thead>
<table width="924" border="0" align="center" cellpadding="5" cellspacing="10">
  <tr>
    <th colspan="2" bgcolor="#663300" scope="col">Our Human resource managers are in charge of every aspect of the employee life cycle in an organization. The responsibilities of HR include preparing or updating employment records related to <span class="j">hiring, transferring, promoting, and terminating.</span></th>
  </tr>
  <tr>
    <th width="259" scope="row"><img src="download (1).jpg" width="259" height="194" /></th>
    <td width="553"><h2><span id="Planning">Planning</span></h2>
    <p><span style="text-transform: capitalize; color: #006; font-variant: small-caps; font-weight: lighter; line-height: normal; font-style: italic; font-size: 12px; font-family: serif, Roman, Modern;">Administration and operations used to be the two role areas of HR. The strategic planning component came into play as a result of companies recognizing the need to consider HR needs in goals and strategies. HR directors commonly sit on company executive teams because of the HR planning function. Numbers and types of employees and the evolution of compensation systems are among elements in the planning role. Various factors affecting Human Resource planning Organizational Structure, Growth, Business Location, Demographic changes, environmental uncertainties, expansion etc. Additionally, this area encompasses the realm of <a href="https://en.wikipedia.org/wiki/Talent_management" title="Talent management">talent management</a>.</span></p></td>
  </tr>
  <tr>
    <th scope="row"><img src="submit.png" width="259" height="194" /></th>
    <td><h2><span id="Development">Development</span></h2>
    <p>Human resource companies play an important part of developing and making a company or organization at the beginning or making a success at the end, due to the labor provided by employees. Human resources is intended to show how to have better employment relations in the workforce. Also, to bring out the best work ethic of the employees and therefore making a move to a better working environment.</p></td>
  </tr>
  <tr>
    <th scope="row"><img src="services_but.png" width="259" height="194" /></th>
    <td><h2><span id="Concerns_about_the_terminology">Terminology</span></h2>
    <p>One major concern about considering people as assets or resources is that they will be commoditized, objectified and abused. Human beings are not &quot;<a href="https://en.wikipedia.org/wiki/Good_(economics_and_accounting)" title="Good (economics and accounting)">commodities</a>&quot; or &quot;resources&quot;, but are creative and social beings in a productive enterprise. The 2000 revision of <a href="https://en.wikipedia.org/wiki/ISO_9001" title="ISO 9001">ISO 9001</a>, in contrast, requires identifying the processes, their sequence and interaction, and to define and communicate responsibilities and authorities. In general, heavily unionized nations such as <a href="https://en.wikipedia.org/wiki/France" title="France">France</a> and <a href="https://en.wikipedia.org/wiki/Germany" title="Germany">Germany</a> have adopted and encouraged such approaches. </p></td>
  </tr>
</table>
</body>
</html>