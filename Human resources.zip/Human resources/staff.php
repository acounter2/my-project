<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>human resources system</title>
<style type="text/css">
body {
	background-color: #999;
}
#J {
	color: #630;
}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: underline;
}
a:active {
	text-decoration: none;
}
</style>
</head>


<body><CENTER>
<img src="HR.png" width="1200" height="183" /><thead align="center" valign="middle" bgcolor="#669999">
<a href="index.php">Visit our page</a>
</thead><thead align="center" valign="middle" bgcolor="#669999">
<span style="color: #999; font-family: 'Lucida Sans Unicode', 'Lucida Grande', sans-serif;">HOMEPAGE2</span>
</thead></CENTER><thead align="center" valign="middle" bgcolor="#669999">
<a href="ono.php">TRANSFER N TERMINATE</a>
</thead>
<thead align="center" valign="middle" bgcolor="#669999">
<span style="color: #999; font-family: 'Lucida Sans Unicode', 'Lucida Grande', sans-serif;">HOMEPAGE4</span>
</thead>
<a href="staff.php">
</CENTER>
</a>
<thead align="center" valign="middle" bgcolor="#669999">
<a href="staff.php">STAFF PROMOTION
</thead>
</a>
<thead align="center" valign="middle" bgcolor="#669999">
<span style="color: #999; font-family: 'Lucida Sans Unicode', 'Lucida Grande', sans-serif;">HOMEPAGE6</span>
<a href="hiring.php">
</thead>
</CENTER>
</a>
<thead align="center" valign="middle" bgcolor="#669999">
<a href="hiring.php">HIRING AND RECRUITING
</thead>
</a>
<thead align="center" valign="middle" bgcolor="#669999">
<a href="hiring.php"><span style="color: #999; font-family: 'Lucida Sans Unicode', 'Lucida Grande', sans-serif;">V</span></a><span style="color: #999; font-family: 'Lucida Sans Unicode', 'Lucida Grande', sans-serif;">isit our page8</span>
</thead><span style="color: #999; font-family: 'Lucida Sans Unicode', 'Lucida Grande', sans-serif;">HOMEPAGE6</span>
<a href="rota.php">
</thead>
</CENTER>
</a>
<thead align="center" valign="middle" bgcolor="#669999">
<a href="rota.php">ROTA MANAGEMENT
</thead>
</a>
<thead align="center" valign="middle" bgcolor="#669999">
<p><span style="color: #999; font-family: 'Lucida Sans Unicode', 'Lucida Grande', sans-serif;">Visit our page8</span>
  </thead>
</p>
<table width="828" border="1" align="center" cellpadding="7" cellspacing="15">
  <tr bgcolor="#666699">
    <th colspan="5" scope="col"><img src="services_but.png" width="151" height="120" /></th>
  </tr>
  <tr bgcolor="#66CCCC">
    <th width="75" scope="col">STAFF ID</th>
    <th width="227" scope="col">FULL NAME</th>
    <th width="156" scope="col">ORGANISATION</th>
    <th width="99" scope="col">LEVEL</th>
    <th width="99" scope="col">STATUS</th>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td>2532</td>
    <td>YUSUF SULAIMAN</td>
    <td>ACCES BANK</td>
    <td bgcolor="#FFFFFF">8</td>
    <td bgcolor="#FF0000">PENDING</td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td>25622</td>
    <td>PAUL DANIEL</td>
    <td>MOTHERCAT PLC</td>
    <td bgcolor="#FFFFFF">12</td>
    <td bgcolor="#00FF00">PROMOTED</td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td>5522</td>
    <td>DAUDA NAFISA</td>
    <td>CGC NIG LTD.</td>
    <td bgcolor="#FFFFFF">16</td>
    <td bgcolor="#00FF00">PROMOTED</td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td>2555</td>
    <td>BAYO OKOYE</td>
    <td>INDOMIE NG LTD.</td>
    <td bgcolor="#FFFFFF">7</td>
    <td bgcolor="#FF0000">PENDING</td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td>5444</td>
    <td>OKECHUWU CHARLIE</td>
    <td>SUNU PLC</td>
    <td bgcolor="#FFFFFF">15</td>
    <td bgcolor="#FF0000">PENDING</td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td>22222</td>
    <td>AMINA GARBA</td>
    <td>ARMY HOSPITAL</td>
    <td bgcolor="#FFFFFF">16</td>
    <td bgcolor="#00FF00">PROMOTED</td>
  </tr>
</table>
<p>&nbsp;</p>
</body>
</html>